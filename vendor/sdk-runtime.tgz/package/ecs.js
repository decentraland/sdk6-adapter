/**
 * The module ecs is exposed by the sdk via `@dcl/sdk/ecs`
 *
 * It defines the engine, components & systems for the SDK 7.

* @example
 * ```tsx
 * import { engine, Transform } from '@dcl/sdk/ecs'
 * const entity = engine.addEntity()
 * Transform.create(entity, defaultPosition)
 * ```
 *
 * @module ECS
 *
 */
export * from '@dcl/ecs';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWNzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic3JjL2Vjcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7Ozs7R0FjRztBQUVILGNBQWMsVUFBVSxDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBUaGUgbW9kdWxlIGVjcyBpcyBleHBvc2VkIGJ5IHRoZSBzZGsgdmlhIGBAZGNsL3Nkay9lY3NgXG4gKlxuICogSXQgZGVmaW5lcyB0aGUgZW5naW5lLCBjb21wb25lbnRzICYgc3lzdGVtcyBmb3IgdGhlIFNESyA3LlxuXG4qIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGltcG9ydCB7IGVuZ2luZSwgVHJhbnNmb3JtIH0gZnJvbSAnQGRjbC9zZGsvZWNzJ1xuICogY29uc3QgZW50aXR5ID0gZW5naW5lLmFkZEVudGl0eSgpXG4gKiBUcmFuc2Zvcm0uY3JlYXRlKGVudGl0eSwgZGVmYXVsdFBvc2l0aW9uKVxuICogYGBgXG4gKlxuICogQG1vZHVsZSBFQ1NcbiAqXG4gKi9cblxuZXhwb3J0ICogZnJvbSAnQGRjbC9lY3MnXG4iXX0=