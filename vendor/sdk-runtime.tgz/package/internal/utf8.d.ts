/**
 * Self-contained UTF-8 codec implementing the WHATWG Encoding Standard
 * algorithms (https://encoding.spec.whatwg.org/), so SDK code never depends
 * on the host providing `TextEncoder` / `TextDecoder` globals.
 */
export type DecodeUtf8Options = {
    fatal?: boolean;
    ignoreBOM?: boolean;
};
export declare function decodeUtf8(input: Uint8Array, options?: DecodeUtf8Options): string;
export declare function encodeUtf8(input: string): Uint8Array;
export declare function encodeUtf8Into(source: string, destination: Uint8Array): {
    read: number;
    written: number;
};
