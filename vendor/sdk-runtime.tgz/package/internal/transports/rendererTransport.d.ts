/// <reference types="@dcl/js-runtime" />
import { Transport } from '@dcl/ecs';
import type { CrdtSendToRendererRequest, CrdtSendToResponse } from '~system/EngineApi';
export type EngineApiForTransport = {
    crdtSendToRenderer(body: CrdtSendToRendererRequest): Promise<CrdtSendToResponse>;
};
export declare function createRendererTransport(engineApi: EngineApiForTransport): Transport;
