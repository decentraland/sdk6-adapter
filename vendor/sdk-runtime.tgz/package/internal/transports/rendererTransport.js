import { MAX_STATIC_COMPONENT } from '@dcl/ecs/dist/components/component-number';
export function createRendererTransport(engineApi) {
    async function sendToRenderer(message) {
        const response = await engineApi.crdtSendToRenderer({
            data: new Uint8Array(message)
        });
        if (response && response.data && response.data.length) {
            if (rendererTransport.onmessage) {
                for (const byteArray of response.data) {
                    rendererTransport.onmessage(byteArray);
                }
            }
        }
    }
    const rendererTransport = {
        async send(message) {
            try {
                await sendToRenderer(message);
            }
            catch (error) {
                // this is the console.error of the scene
                // eslint-disable-next-line no-console
                console.error(error);
                debugger;
            }
        },
        filter(message) {
            // Only send renderer components (Proto Generated)
            if (
            // filter out messages for non-core components
            message.componentId > MAX_STATIC_COMPONENT) {
                return false;
            }
            return !!message;
        },
        type: 'renderer'
    };
    return rendererTransport;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVuZGVyZXJUcmFuc3BvcnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvaW50ZXJuYWwvdHJhbnNwb3J0cy9yZW5kZXJlclRyYW5zcG9ydC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSwyQ0FBMkMsQ0FBQTtBQU9oRixNQUFNLFVBQVUsdUJBQXVCLENBQUMsU0FBZ0M7SUFDdEUsS0FBSyxVQUFVLGNBQWMsQ0FBQyxPQUFtQjtRQUMvQyxNQUFNLFFBQVEsR0FBRyxNQUFNLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQztZQUNsRCxJQUFJLEVBQUUsSUFBSSxVQUFVLENBQUMsT0FBTyxDQUFDO1NBQzlCLENBQUMsQ0FBQTtRQUNGLElBQUksUUFBUSxJQUFJLFFBQVEsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDckQsSUFBSSxpQkFBaUIsQ0FBQyxTQUFTLEVBQUU7Z0JBQy9CLEtBQUssTUFBTSxTQUFTLElBQUksUUFBUSxDQUFDLElBQUksRUFBRTtvQkFDckMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFBO2lCQUN2QzthQUNGO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsTUFBTSxpQkFBaUIsR0FBYztRQUNuQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU87WUFDaEIsSUFBSTtnQkFDRixNQUFNLGNBQWMsQ0FBQyxPQUFxQixDQUFDLENBQUE7YUFDNUM7WUFBQyxPQUFPLEtBQUssRUFBRTtnQkFDZCx5Q0FBeUM7Z0JBQ3pDLHNDQUFzQztnQkFDdEMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQTtnQkFDcEIsUUFBUSxDQUFBO2FBQ1Q7UUFDSCxDQUFDO1FBQ0QsTUFBTSxDQUFDLE9BQXlCO1lBQzlCLGtEQUFrRDtZQUNsRDtZQUNFLDhDQUE4QztZQUM3QyxPQUFlLENBQUMsV0FBVyxHQUFHLG9CQUFvQixFQUNuRDtnQkFDQSxPQUFPLEtBQUssQ0FBQTthQUNiO1lBQ0QsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFBO1FBQ2xCLENBQUM7UUFDRCxJQUFJLEVBQUUsVUFBVTtLQUNqQixDQUFBO0lBRUQsT0FBTyxpQkFBaUIsQ0FBQTtBQUMxQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVHJhbnNwb3J0LCBUcmFuc3BvcnRNZXNzYWdlIH0gZnJvbSAnQGRjbC9lY3MnXG5pbXBvcnQgeyBNQVhfU1RBVElDX0NPTVBPTkVOVCB9IGZyb20gJ0BkY2wvZWNzL2Rpc3QvY29tcG9uZW50cy9jb21wb25lbnQtbnVtYmVyJ1xuaW1wb3J0IHR5cGUgeyBDcmR0U2VuZFRvUmVuZGVyZXJSZXF1ZXN0LCBDcmR0U2VuZFRvUmVzcG9uc2UgfSBmcm9tICd+c3lzdGVtL0VuZ2luZUFwaSdcblxuZXhwb3J0IHR5cGUgRW5naW5lQXBpRm9yVHJhbnNwb3J0ID0ge1xuICBjcmR0U2VuZFRvUmVuZGVyZXIoYm9keTogQ3JkdFNlbmRUb1JlbmRlcmVyUmVxdWVzdCk6IFByb21pc2U8Q3JkdFNlbmRUb1Jlc3BvbnNlPlxufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUmVuZGVyZXJUcmFuc3BvcnQoZW5naW5lQXBpOiBFbmdpbmVBcGlGb3JUcmFuc3BvcnQpOiBUcmFuc3BvcnQge1xuICBhc3luYyBmdW5jdGlvbiBzZW5kVG9SZW5kZXJlcihtZXNzYWdlOiBVaW50OEFycmF5KSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBlbmdpbmVBcGkuY3JkdFNlbmRUb1JlbmRlcmVyKHtcbiAgICAgIGRhdGE6IG5ldyBVaW50OEFycmF5KG1lc3NhZ2UpXG4gICAgfSlcbiAgICBpZiAocmVzcG9uc2UgJiYgcmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCkge1xuICAgICAgaWYgKHJlbmRlcmVyVHJhbnNwb3J0Lm9ubWVzc2FnZSkge1xuICAgICAgICBmb3IgKGNvbnN0IGJ5dGVBcnJheSBvZiByZXNwb25zZS5kYXRhKSB7XG4gICAgICAgICAgcmVuZGVyZXJUcmFuc3BvcnQub25tZXNzYWdlKGJ5dGVBcnJheSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHJlbmRlcmVyVHJhbnNwb3J0OiBUcmFuc3BvcnQgPSB7XG4gICAgYXN5bmMgc2VuZChtZXNzYWdlKSB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBzZW5kVG9SZW5kZXJlcihtZXNzYWdlIGFzIFVpbnQ4QXJyYXkpXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAvLyB0aGlzIGlzIHRoZSBjb25zb2xlLmVycm9yIG9mIHRoZSBzY2VuZVxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29uc29sZVxuICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKVxuICAgICAgICBkZWJ1Z2dlclxuICAgICAgfVxuICAgIH0sXG4gICAgZmlsdGVyKG1lc3NhZ2U6IFRyYW5zcG9ydE1lc3NhZ2UpIHtcbiAgICAgIC8vIE9ubHkgc2VuZCByZW5kZXJlciBjb21wb25lbnRzIChQcm90byBHZW5lcmF0ZWQpXG4gICAgICBpZiAoXG4gICAgICAgIC8vIGZpbHRlciBvdXQgbWVzc2FnZXMgZm9yIG5vbi1jb3JlIGNvbXBvbmVudHNcbiAgICAgICAgKG1lc3NhZ2UgYXMgYW55KS5jb21wb25lbnRJZCA+IE1BWF9TVEFUSUNfQ09NUE9ORU5UXG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgICByZXR1cm4gISFtZXNzYWdlXG4gICAgfSxcbiAgICB0eXBlOiAncmVuZGVyZXInXG4gIH1cblxuICByZXR1cm4gcmVuZGVyZXJUcmFuc3BvcnRcbn1cbiJdfQ==