import { IEngine } from '@dcl/ecs';
export declare function serializeCrdtMessages(prefix: string, data: Uint8Array, engine: IEngine): Generator<string, void, unknown>;
