/* istanbul ignore file */
/**
 * A class serves as a medium between the observable and its observers
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed
 * @public
 */
export class ObserverEventState {
    /**
     * Create a new EventState
     * @param mask - defines the mask associated with this state
     * @param skipNextObservers - defines a flag which will instruct the observable to skip following observers when set to true
     * @param target - defines the original target of the state
     * @param currentTarget - defines the current target of the state
     */
    constructor(mask, skipNextObservers = false, target, currentTarget) {
        this.initalize(mask, skipNextObservers, target, currentTarget);
    }
    /**
     * Initialize the current event state
     * @param mask - defines the mask associated with this state
     * @param skipNextObservers - defines a flag which will instruct the observable to skip following observers when set to true
     * @param target - defines the original target of the state
     * @param currentTarget - defines the current target of the state
     * @returns the current event state
     */
    initalize(mask, skipNextObservers = false, target, currentTarget) {
        this.mask = mask;
        this.skipNextObservers = skipNextObservers;
        this.target = target;
        this.currentTarget = currentTarget;
        return this;
    }
}
/**
 * Represent an Observer registered to a given Observable object.
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed
 * @public
 */
export class Observer {
    /**
     * Creates a new observer
     * @param callback - defines the callback to call when the observer is notified
     * @param mask - defines the mask of the observer (used to filter notifications)
     * @param scope - defines the current scope used to restore the JS context
     */
    constructor(
    /**
     * Defines the callback to call when the observer is notified
     */
    callback, 
    /**
     * Defines the mask of the observer (used to filter notifications)
     */
    mask, 
    /**
     * Defines the current scope used to restore the JS context
     */
    scope = null) {
        this.callback = callback;
        this.mask = mask;
        this.scope = scope;
        /**
         * Gets or sets a property defining that the observer as to be unregistered after the next notification
         */
        this.unregisterOnNextCall = false;
        /** For internal usage */
        this._willBeUnregistered = false;
    }
}
/**
 * The Observable class is a simple implementation of the Observable pattern.
 *
 * There's one slight particularity though: a given Observable can notify its observer using a particular mask value, only the Observers registered with this mask value will be notified.
 * This enable a more fine grained execution without having to rely on multiple different Observable objects.
 * For instance you may have a given Observable that have four different types of notifications: Move (mask = 0x01), Stop (mask = 0x02), Turn Right (mask = 0X04), Turn Left (mask = 0X08).
 * A given observer can register itself with only Move and Stop (mask = 0x03), then it will only be notified when one of these two occurs and will never be for Turn Left/Right.
 *
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed
 */
export class Observable {
    /**
     * Creates a new observable
     * @param onObserverAdded - defines a callback to call when a new observer is added
     */
    constructor(onObserverAdded) {
        this._observers = new Array();
        this._onObserverAdded = null;
        this._eventState = new ObserverEventState(0);
        if (onObserverAdded) {
            this._onObserverAdded = onObserverAdded;
        }
    }
    /**
     * Create a new Observer with the specified callback
     * @param callback - the callback that will be executed for that Observer
     * @param mask - the mask used to filter observers
     * @param insertFirst - if true the callback will be inserted at the first position, hence executed before the others ones. If false (default behavior) the callback will be inserted at the last position, executed after all the others already present.
     * @param scope - optional scope for the callback to be called from
     * @param unregisterOnFirstCall - defines if the observer as to be unregistered after the next notification
     * @returns the new observer created for the callback
     */
    add(callback, mask = -1, insertFirst = false, scope = null, unregisterOnFirstCall = false) {
        if (!callback) {
            return null;
        }
        const observer = new Observer(callback, mask, scope);
        observer.unregisterOnNextCall = unregisterOnFirstCall;
        if (insertFirst) {
            this._observers.unshift(observer);
        }
        else {
            this._observers.push(observer);
        }
        if (this._onObserverAdded) {
            this._onObserverAdded(observer);
        }
        return observer;
    }
    /**
     * Create a new Observer with the specified callback and unregisters after the next notification
     * @param callback - the callback that will be executed for that Observer
     * @returns the new observer created for the callback
     */
    addOnce(callback) {
        return this.add(callback, undefined, undefined, undefined, true);
    }
    /**
     * Remove an Observer from the Observable object
     * @param observer - the instance of the Observer to remove
     * @returns false if it doesn't belong to this Observable
     */
    remove(observer) {
        if (!observer) {
            return false;
        }
        const index = this._observers.indexOf(observer);
        if (index !== -1) {
            this._deferUnregister(observer);
            return true;
        }
        return false;
    }
    /**
     * Remove a callback from the Observable object
     * @param callback - the callback to remove
     * @param scope - optional scope. If used only the callbacks with this scope will be removed
     * @returns false if it doesn't belong to this Observable
     */
    removeCallback(callback, scope) {
        for (let index = 0; index < this._observers.length; index++) {
            if (this._observers[index].callback === callback && (!scope || scope === this._observers[index].scope)) {
                this._deferUnregister(this._observers[index]);
                return true;
            }
        }
        return false;
    }
    /**
     * Notify all Observers by calling their respective callback with the given data
     * Will return true if all observers were executed, false if an observer set skipNextObservers to true, then prevent the subsequent ones to execute
     * @param eventData - defines the data to send to all observers
     * @param mask - defines the mask of the current notification (observers with incompatible mask (ie mask & observer.mask === 0) will not be notified)
     * @param target - defines the original target of the state
     * @param currentTarget - defines the current target of the state
     * @returns false if the complete observer chain was not processed (because one observer set the skipNextObservers to true)
     */
    notifyObservers(eventData, mask = -1, target, currentTarget) {
        if (!this._observers.length) {
            return true;
        }
        const state = this._eventState;
        state.mask = mask;
        state.target = target;
        state.currentTarget = currentTarget;
        state.skipNextObservers = false;
        state.lastReturnValue = eventData;
        for (const obs of this._observers) {
            if (obs._willBeUnregistered) {
                continue;
            }
            if (obs.mask & mask) {
                if (obs.scope) {
                    state.lastReturnValue = obs.callback.apply(obs.scope, [eventData, state]);
                }
                else {
                    state.lastReturnValue = obs.callback(eventData, state);
                }
                if (obs.unregisterOnNextCall) {
                    this._deferUnregister(obs);
                }
            }
            if (state.skipNextObservers) {
                return false;
            }
        }
        return true;
    }
    /**
     * Calling this will execute each callback, expecting it to be a promise or return a value.
     * If at any point in the chain one function fails, the promise will fail and the execution will not continue.
     * This is useful when a chain of events (sometimes async events) is needed to initialize a certain object
     * and it is crucial that all callbacks will be executed.
     * The order of the callbacks is kept, callbacks are not executed parallel.
     *
     * @param eventData - The data to be sent to each callback
     * @param mask - is used to filter observers defaults to -1
     * @param target - defines the callback target (see EventState)
     * @param currentTarget - defines he current object in the bubbling phase
     * @returns will return a Promise than resolves when all callbacks executed successfully.
     */
    notifyObserversWithPromise(eventData, mask = -1, target, currentTarget) {
        // create an empty promise
        let p = Promise.resolve(eventData);
        // no observers? return this promise.
        if (!this._observers.length) {
            return p;
        }
        const state = this._eventState;
        state.mask = mask;
        state.target = target;
        state.currentTarget = currentTarget;
        state.skipNextObservers = false;
        // execute one callback after another (not using Promise.all, the order is important)
        this._observers.forEach((obs) => {
            if (state.skipNextObservers) {
                return;
            }
            if (obs._willBeUnregistered) {
                return;
            }
            if (obs.mask & mask) {
                if (obs.scope) {
                    p = p.then((lastReturnedValue) => {
                        state.lastReturnValue = lastReturnedValue;
                        return obs.callback.apply(obs.scope, [eventData, state]);
                    });
                }
                else {
                    p = p.then((lastReturnedValue) => {
                        state.lastReturnValue = lastReturnedValue;
                        return obs.callback(eventData, state);
                    });
                }
                if (obs.unregisterOnNextCall) {
                    this._deferUnregister(obs);
                }
            }
        });
        // return the eventData
        return p.then(() => {
            return eventData;
        });
    }
    /**
     * Notify a specific observer
     * @param observer - defines the observer to notify
     * @param eventData - defines the data to be sent to each callback
     * @param mask - is used to filter observers defaults to -1
     */
    notifyObserver(observer, eventData, mask = -1) {
        const state = this._eventState;
        state.mask = mask;
        state.skipNextObservers = false;
        observer.callback(eventData, state);
    }
    /**
     * Gets a boolean indicating if the observable has at least one observer
     * @returns true is the Observable has at least one Observer registered
     */
    hasObservers() {
        return this._observers.length > 0;
    }
    /**
     * Clear the list of observers
     */
    clear() {
        this._observers = new Array();
        this._onObserverAdded = null;
    }
    /**
     * Clone the current observable
     * @returns a new observable
     */
    clone() {
        const result = new Observable();
        result._observers = this._observers.slice(0);
        return result;
    }
    /**
     * Does this observable handles observer registered with a given mask
     * @param mask - defines the mask to be tested
     * @returns whether or not one observer registered with the given mask is handeled
     */
    hasSpecificMask(mask = -1) {
        for (const obs of this._observers) {
            if (obs.mask & mask || obs.mask === mask) {
                return true;
            }
        }
        return false;
    }
    _deferUnregister(observer) {
        observer.unregisterOnNextCall = false;
        observer._willBeUnregistered = true;
        Promise.resolve()
            .then.bind(Promise.resolve())(async () => this._remove(observer))
            .catch(console.error);
    }
    // This should only be called when not iterating over _observers to avoid callback skipping.
    // Removes an observer from the _observer Array.
    _remove(observer) {
        if (!observer) {
            return false;
        }
        const index = this._observers.indexOf(observer);
        if (index !== -1) {
            this._observers.splice(index, 1);
            return true;
        }
        return false;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiT2JzZXJ2YWJsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3NyYy9pbnRlcm5hbC9PYnNlcnZhYmxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLDBCQUEwQjtBQUMxQjs7OztHQUlHO0FBQ0gsTUFBTSxPQUFPLGtCQUFrQjtJQTJCN0I7Ozs7OztPQU1HO0lBQ0gsWUFBWSxJQUFZLEVBQUUsaUJBQWlCLEdBQUcsS0FBSyxFQUFFLE1BQVksRUFBRSxhQUFtQjtRQUNwRixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsYUFBYSxDQUFDLENBQUE7SUFDaEUsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSSxTQUFTLENBQUMsSUFBWSxFQUFFLGlCQUFpQixHQUFHLEtBQUssRUFBRSxNQUFZLEVBQUUsYUFBbUI7UUFDekYsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUE7UUFDaEIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLGlCQUFpQixDQUFBO1FBQzFDLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFBO1FBQ3BCLElBQUksQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFBO1FBQ2xDLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztDQUNGO0FBRUQ7Ozs7R0FJRztBQUNILE1BQU0sT0FBTyxRQUFRO0lBU25COzs7OztPQUtHO0lBQ0g7SUFDRTs7T0FFRztJQUNJLFFBQWdFO0lBQ3ZFOztPQUVHO0lBQ0ksSUFBWTtJQUNuQjs7T0FFRztJQUNJLFFBQWEsSUFBSTtRQVJqQixhQUFRLEdBQVIsUUFBUSxDQUF3RDtRQUloRSxTQUFJLEdBQUosSUFBSSxDQUFRO1FBSVosVUFBSyxHQUFMLEtBQUssQ0FBWTtRQTFCMUI7O1dBRUc7UUFDSSx5QkFBb0IsR0FBRyxLQUFLLENBQUE7UUFFbkMseUJBQXlCO1FBQ2xCLHdCQUFtQixHQUFHLEtBQUssQ0FBQTtJQXFCL0IsQ0FBQztDQUNMO0FBRUQ7Ozs7Ozs7Ozs7R0FVRztBQUNILE1BQU0sT0FBTyxVQUFVO0lBT3JCOzs7T0FHRztJQUNILFlBQVksZUFBaUQ7UUFWckQsZUFBVSxHQUFHLElBQUksS0FBSyxFQUFlLENBQUE7UUFJckMscUJBQWdCLEdBQTZDLElBQUksQ0FBQTtRQU92RSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFFNUMsSUFBSSxlQUFlLEVBQUU7WUFDbkIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLGVBQWUsQ0FBQTtTQUN4QztJQUNILENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNJLEdBQUcsQ0FDUixRQUFnRSxFQUNoRSxPQUFlLENBQUMsQ0FBQyxFQUNqQixXQUFXLEdBQUcsS0FBSyxFQUNuQixRQUFhLElBQUksRUFDakIscUJBQXFCLEdBQUcsS0FBSztRQUU3QixJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2IsT0FBTyxJQUFJLENBQUE7U0FDWjtRQUVELE1BQU0sUUFBUSxHQUFHLElBQUksUUFBUSxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDcEQsUUFBUSxDQUFDLG9CQUFvQixHQUFHLHFCQUFxQixDQUFBO1FBRXJELElBQUksV0FBVyxFQUFFO1lBQ2YsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUE7U0FDbEM7YUFBTTtZQUNMLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1NBQy9CO1FBRUQsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDekIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFBO1NBQ2hDO1FBRUQsT0FBTyxRQUFRLENBQUE7SUFDakIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxPQUFPLENBQUMsUUFBZ0U7UUFDN0UsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQTtJQUNsRSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLE1BQU0sQ0FBQyxRQUE0QjtRQUN4QyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2IsT0FBTyxLQUFLLENBQUE7U0FDYjtRQUVELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO1FBRS9DLElBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxFQUFFO1lBQ2hCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQTtZQUMvQixPQUFPLElBQUksQ0FBQTtTQUNaO1FBRUQsT0FBTyxLQUFLLENBQUE7SUFDZCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxjQUFjLENBQUMsUUFBZ0UsRUFBRSxLQUFXO1FBQ2pHLEtBQUssSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUMzRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxLQUFLLFFBQVEsSUFBSSxDQUFDLENBQUMsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUN0RyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFBO2dCQUM3QyxPQUFPLElBQUksQ0FBQTthQUNaO1NBQ0Y7UUFFRCxPQUFPLEtBQUssQ0FBQTtJQUNkLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNJLGVBQWUsQ0FBQyxTQUFZLEVBQUUsT0FBZSxDQUFDLENBQUMsRUFBRSxNQUFZLEVBQUUsYUFBbUI7UUFDdkYsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFO1lBQzNCLE9BQU8sSUFBSSxDQUFBO1NBQ1o7UUFFRCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFBO1FBQzlCLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFBO1FBQ2pCLEtBQUssQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFBO1FBQ3JCLEtBQUssQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFBO1FBQ25DLEtBQUssQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUE7UUFDL0IsS0FBSyxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUE7UUFFakMsS0FBSyxNQUFNLEdBQUcsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2pDLElBQUksR0FBRyxDQUFDLG1CQUFtQixFQUFFO2dCQUMzQixTQUFRO2FBQ1Q7WUFFRCxJQUFJLEdBQUcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxFQUFFO2dCQUNuQixJQUFJLEdBQUcsQ0FBQyxLQUFLLEVBQUU7b0JBQ2IsS0FBSyxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUE7aUJBQzFFO3FCQUFNO29CQUNMLEtBQUssQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUE7aUJBQ3ZEO2dCQUVELElBQUksR0FBRyxDQUFDLG9CQUFvQixFQUFFO29CQUM1QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUE7aUJBQzNCO2FBQ0Y7WUFDRCxJQUFJLEtBQUssQ0FBQyxpQkFBaUIsRUFBRTtnQkFDM0IsT0FBTyxLQUFLLENBQUE7YUFDYjtTQUNGO1FBQ0QsT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ0ksMEJBQTBCLENBQUMsU0FBWSxFQUFFLE9BQWUsQ0FBQyxDQUFDLEVBQUUsTUFBWSxFQUFFLGFBQW1CO1FBQ2xHLDBCQUEwQjtRQUMxQixJQUFJLENBQUMsR0FBaUIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQTtRQUVoRCxxQ0FBcUM7UUFDckMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFO1lBQzNCLE9BQU8sQ0FBQyxDQUFBO1NBQ1Q7UUFFRCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFBO1FBQzlCLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFBO1FBQ2pCLEtBQUssQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFBO1FBQ3JCLEtBQUssQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFBO1FBQ25DLEtBQUssQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUE7UUFFL0IscUZBQXFGO1FBQ3JGLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDOUIsSUFBSSxLQUFLLENBQUMsaUJBQWlCLEVBQUU7Z0JBQzNCLE9BQU07YUFDUDtZQUNELElBQUksR0FBRyxDQUFDLG1CQUFtQixFQUFFO2dCQUMzQixPQUFNO2FBQ1A7WUFDRCxJQUFJLEdBQUcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxFQUFFO2dCQUNuQixJQUFJLEdBQUcsQ0FBQyxLQUFLLEVBQUU7b0JBQ2IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxFQUFFO3dCQUMvQixLQUFLLENBQUMsZUFBZSxHQUFHLGlCQUFpQixDQUFBO3dCQUN6QyxPQUFPLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQTtvQkFDMUQsQ0FBQyxDQUFDLENBQUE7aUJBQ0g7cUJBQU07b0JBQ0wsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxFQUFFO3dCQUMvQixLQUFLLENBQUMsZUFBZSxHQUFHLGlCQUFpQixDQUFBO3dCQUN6QyxPQUFPLEdBQUcsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFBO29CQUN2QyxDQUFDLENBQUMsQ0FBQTtpQkFDSDtnQkFDRCxJQUFJLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRTtvQkFDNUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFBO2lCQUMzQjthQUNGO1FBQ0gsQ0FBQyxDQUFDLENBQUE7UUFFRix1QkFBdUI7UUFDdkIsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUNqQixPQUFPLFNBQVMsQ0FBQTtRQUNsQixDQUFDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGNBQWMsQ0FBQyxRQUFxQixFQUFFLFNBQVksRUFBRSxPQUFlLENBQUMsQ0FBQztRQUMxRSxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFBO1FBQzlCLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFBO1FBQ2pCLEtBQUssQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUE7UUFFL0IsUUFBUSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUE7SUFDckMsQ0FBQztJQUVEOzs7T0FHRztJQUNJLFlBQVk7UUFDakIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUE7SUFDbkMsQ0FBQztJQUVEOztPQUVHO0lBQ0ksS0FBSztRQUNWLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxLQUFLLEVBQWUsQ0FBQTtRQUMxQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFBO0lBQzlCLENBQUM7SUFFRDs7O09BR0c7SUFDSSxLQUFLO1FBQ1YsTUFBTSxNQUFNLEdBQUcsSUFBSSxVQUFVLEVBQUssQ0FBQTtRQUVsQyxNQUFNLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBRTVDLE9BQU8sTUFBTSxDQUFBO0lBQ2YsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxlQUFlLENBQUMsT0FBZSxDQUFDLENBQUM7UUFDdEMsS0FBSyxNQUFNLEdBQUcsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2pDLElBQUksR0FBRyxDQUFDLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxDQUFDLElBQUksS0FBSyxJQUFJLEVBQUU7Z0JBQ3hDLE9BQU8sSUFBSSxDQUFBO2FBQ1o7U0FDRjtRQUNELE9BQU8sS0FBSyxDQUFBO0lBQ2QsQ0FBQztJQUVPLGdCQUFnQixDQUFDLFFBQXFCO1FBQzVDLFFBQVEsQ0FBQyxvQkFBb0IsR0FBRyxLQUFLLENBQUE7UUFDckMsUUFBUSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQTtRQUNuQyxPQUFPLENBQUMsT0FBTyxFQUFFO2FBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDaEUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUN6QixDQUFDO0lBRUQsNEZBQTRGO0lBQzVGLGdEQUFnRDtJQUN4QyxPQUFPLENBQUMsUUFBNEI7UUFDMUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLE9BQU8sS0FBSyxDQUFBO1NBQ2I7UUFFRCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUUvQyxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsRUFBRTtZQUNoQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUE7WUFDaEMsT0FBTyxJQUFJLENBQUE7U0FDWjtRQUVELE9BQU8sS0FBSyxDQUFBO0lBQ2QsQ0FBQztDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLyogaXN0YW5idWwgaWdub3JlIGZpbGUgKi9cbi8qKlxuICogQSBjbGFzcyBzZXJ2ZXMgYXMgYSBtZWRpdW0gYmV0d2VlbiB0aGUgb2JzZXJ2YWJsZSBhbmQgaXRzIG9ic2VydmVyc1xuICogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiBpcyBhbiBpbmhlcml0YW5jZSBvZiBFQ1M2LCBpdCdzIGhlcmUgdGVtcG9yYXJ5IGZvciB0aGUgZmVhdHVyZSBwYXJpdHksIHBsZWFzZSByZWFkIHRoZSBuZXdzIGFuZCBkb2NzIHRvIGtub3cgaG93IGhhbmRsZSB3aGVuIGl0J3MgcmVtb3ZlZFxuICogQHB1YmxpY1xuICovXG5leHBvcnQgY2xhc3MgT2JzZXJ2ZXJFdmVudFN0YXRlIHtcbiAgLyoqXG4gICAqIEFuIE9ic2VydmVyIGNhbiBzZXQgdGhpcyBwcm9wZXJ0eSB0byB0cnVlIHRvIHByZXZlbnQgc3Vic2VxdWVudCBvYnNlcnZlcnMgb2YgYmVpbmcgbm90aWZpZWRcbiAgICovXG4gIHB1YmxpYyBza2lwTmV4dE9ic2VydmVycyE6IGJvb2xlYW5cblxuICAvKipcbiAgICogR2V0IHRoZSBtYXNrIHZhbHVlIHRoYXQgd2VyZSB1c2VkIHRvIHRyaWdnZXIgdGhlIGV2ZW50IGNvcnJlc3BvbmRpbmcgdG8gdGhpcyBFdmVudFN0YXRlIG9iamVjdFxuICAgKi9cbiAgcHVibGljIG1hc2shOiBudW1iZXJcblxuICAvKipcbiAgICogVGhlIG9iamVjdCB0aGF0IG9yaWdpbmFsbHkgbm90aWZpZWQgdGhlIGV2ZW50XG4gICAqL1xuICBwdWJsaWMgdGFyZ2V0PzogYW55XG5cbiAgLyoqXG4gICAqIFRoZSBjdXJyZW50IG9iamVjdCBpbiB0aGUgYnViYmxpbmcgcGhhc2VcbiAgICovXG4gIHB1YmxpYyBjdXJyZW50VGFyZ2V0PzogYW55XG5cbiAgLyoqXG4gICAqIFRoaXMgd2lsbCBiZSBwb3B1bGF0ZWQgd2l0aCB0aGUgcmV0dXJuIHZhbHVlIG9mIHRoZSBsYXN0IGZ1bmN0aW9uIHRoYXQgd2FzIGV4ZWN1dGVkLlxuICAgKiBJZiBpdCBpcyB0aGUgZmlyc3QgZnVuY3Rpb24gaW4gdGhlIGNhbGxiYWNrIGNoYWluIGl0IHdpbGwgYmUgdGhlIGV2ZW50IGRhdGEuXG4gICAqL1xuICBwdWJsaWMgbGFzdFJldHVyblZhbHVlPzogYW55XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBFdmVudFN0YXRlXG4gICAqIEBwYXJhbSBtYXNrIC0gZGVmaW5lcyB0aGUgbWFzayBhc3NvY2lhdGVkIHdpdGggdGhpcyBzdGF0ZVxuICAgKiBAcGFyYW0gc2tpcE5leHRPYnNlcnZlcnMgLSBkZWZpbmVzIGEgZmxhZyB3aGljaCB3aWxsIGluc3RydWN0IHRoZSBvYnNlcnZhYmxlIHRvIHNraXAgZm9sbG93aW5nIG9ic2VydmVycyB3aGVuIHNldCB0byB0cnVlXG4gICAqIEBwYXJhbSB0YXJnZXQgLSBkZWZpbmVzIHRoZSBvcmlnaW5hbCB0YXJnZXQgb2YgdGhlIHN0YXRlXG4gICAqIEBwYXJhbSBjdXJyZW50VGFyZ2V0IC0gZGVmaW5lcyB0aGUgY3VycmVudCB0YXJnZXQgb2YgdGhlIHN0YXRlXG4gICAqL1xuICBjb25zdHJ1Y3RvcihtYXNrOiBudW1iZXIsIHNraXBOZXh0T2JzZXJ2ZXJzID0gZmFsc2UsIHRhcmdldD86IGFueSwgY3VycmVudFRhcmdldD86IGFueSkge1xuICAgIHRoaXMuaW5pdGFsaXplKG1hc2ssIHNraXBOZXh0T2JzZXJ2ZXJzLCB0YXJnZXQsIGN1cnJlbnRUYXJnZXQpXG4gIH1cblxuICAvKipcbiAgICogSW5pdGlhbGl6ZSB0aGUgY3VycmVudCBldmVudCBzdGF0ZVxuICAgKiBAcGFyYW0gbWFzayAtIGRlZmluZXMgdGhlIG1hc2sgYXNzb2NpYXRlZCB3aXRoIHRoaXMgc3RhdGVcbiAgICogQHBhcmFtIHNraXBOZXh0T2JzZXJ2ZXJzIC0gZGVmaW5lcyBhIGZsYWcgd2hpY2ggd2lsbCBpbnN0cnVjdCB0aGUgb2JzZXJ2YWJsZSB0byBza2lwIGZvbGxvd2luZyBvYnNlcnZlcnMgd2hlbiBzZXQgdG8gdHJ1ZVxuICAgKiBAcGFyYW0gdGFyZ2V0IC0gZGVmaW5lcyB0aGUgb3JpZ2luYWwgdGFyZ2V0IG9mIHRoZSBzdGF0ZVxuICAgKiBAcGFyYW0gY3VycmVudFRhcmdldCAtIGRlZmluZXMgdGhlIGN1cnJlbnQgdGFyZ2V0IG9mIHRoZSBzdGF0ZVxuICAgKiBAcmV0dXJucyB0aGUgY3VycmVudCBldmVudCBzdGF0ZVxuICAgKi9cbiAgcHVibGljIGluaXRhbGl6ZShtYXNrOiBudW1iZXIsIHNraXBOZXh0T2JzZXJ2ZXJzID0gZmFsc2UsIHRhcmdldD86IGFueSwgY3VycmVudFRhcmdldD86IGFueSk6IE9ic2VydmVyRXZlbnRTdGF0ZSB7XG4gICAgdGhpcy5tYXNrID0gbWFza1xuICAgIHRoaXMuc2tpcE5leHRPYnNlcnZlcnMgPSBza2lwTmV4dE9ic2VydmVyc1xuICAgIHRoaXMudGFyZ2V0ID0gdGFyZ2V0XG4gICAgdGhpcy5jdXJyZW50VGFyZ2V0ID0gY3VycmVudFRhcmdldFxuICAgIHJldHVybiB0aGlzXG4gIH1cbn1cblxuLyoqXG4gKiBSZXByZXNlbnQgYW4gT2JzZXJ2ZXIgcmVnaXN0ZXJlZCB0byBhIGdpdmVuIE9ic2VydmFibGUgb2JqZWN0LlxuICogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiBpcyBhbiBpbmhlcml0YW5jZSBvZiBFQ1M2LCBpdCdzIGhlcmUgdGVtcG9yYXJ5IGZvciB0aGUgZmVhdHVyZSBwYXJpdHksIHBsZWFzZSByZWFkIHRoZSBuZXdzIGFuZCBkb2NzIHRvIGtub3cgaG93IGhhbmRsZSB3aGVuIGl0J3MgcmVtb3ZlZFxuICogQHB1YmxpY1xuICovXG5leHBvcnQgY2xhc3MgT2JzZXJ2ZXI8VD4ge1xuICAvKipcbiAgICogR2V0cyBvciBzZXRzIGEgcHJvcGVydHkgZGVmaW5pbmcgdGhhdCB0aGUgb2JzZXJ2ZXIgYXMgdG8gYmUgdW5yZWdpc3RlcmVkIGFmdGVyIHRoZSBuZXh0IG5vdGlmaWNhdGlvblxuICAgKi9cbiAgcHVibGljIHVucmVnaXN0ZXJPbk5leHRDYWxsID0gZmFsc2VcblxuICAvKiogRm9yIGludGVybmFsIHVzYWdlICovXG4gIHB1YmxpYyBfd2lsbEJlVW5yZWdpc3RlcmVkID0gZmFsc2VcblxuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBvYnNlcnZlclxuICAgKiBAcGFyYW0gY2FsbGJhY2sgLSBkZWZpbmVzIHRoZSBjYWxsYmFjayB0byBjYWxsIHdoZW4gdGhlIG9ic2VydmVyIGlzIG5vdGlmaWVkXG4gICAqIEBwYXJhbSBtYXNrIC0gZGVmaW5lcyB0aGUgbWFzayBvZiB0aGUgb2JzZXJ2ZXIgKHVzZWQgdG8gZmlsdGVyIG5vdGlmaWNhdGlvbnMpXG4gICAqIEBwYXJhbSBzY29wZSAtIGRlZmluZXMgdGhlIGN1cnJlbnQgc2NvcGUgdXNlZCB0byByZXN0b3JlIHRoZSBKUyBjb250ZXh0XG4gICAqL1xuICBjb25zdHJ1Y3RvcihcbiAgICAvKipcbiAgICAgKiBEZWZpbmVzIHRoZSBjYWxsYmFjayB0byBjYWxsIHdoZW4gdGhlIG9ic2VydmVyIGlzIG5vdGlmaWVkXG4gICAgICovXG4gICAgcHVibGljIGNhbGxiYWNrOiAoZXZlbnREYXRhOiBULCBldmVudFN0YXRlOiBPYnNlcnZlckV2ZW50U3RhdGUpID0+IHZvaWQsXG4gICAgLyoqXG4gICAgICogRGVmaW5lcyB0aGUgbWFzayBvZiB0aGUgb2JzZXJ2ZXIgKHVzZWQgdG8gZmlsdGVyIG5vdGlmaWNhdGlvbnMpXG4gICAgICovXG4gICAgcHVibGljIG1hc2s6IG51bWJlcixcbiAgICAvKipcbiAgICAgKiBEZWZpbmVzIHRoZSBjdXJyZW50IHNjb3BlIHVzZWQgdG8gcmVzdG9yZSB0aGUgSlMgY29udGV4dFxuICAgICAqL1xuICAgIHB1YmxpYyBzY29wZTogYW55ID0gbnVsbFxuICApIHt9XG59XG5cbi8qKlxuICogVGhlIE9ic2VydmFibGUgY2xhc3MgaXMgYSBzaW1wbGUgaW1wbGVtZW50YXRpb24gb2YgdGhlIE9ic2VydmFibGUgcGF0dGVybi5cbiAqXG4gKiBUaGVyZSdzIG9uZSBzbGlnaHQgcGFydGljdWxhcml0eSB0aG91Z2g6IGEgZ2l2ZW4gT2JzZXJ2YWJsZSBjYW4gbm90aWZ5IGl0cyBvYnNlcnZlciB1c2luZyBhIHBhcnRpY3VsYXIgbWFzayB2YWx1ZSwgb25seSB0aGUgT2JzZXJ2ZXJzIHJlZ2lzdGVyZWQgd2l0aCB0aGlzIG1hc2sgdmFsdWUgd2lsbCBiZSBub3RpZmllZC5cbiAqIFRoaXMgZW5hYmxlIGEgbW9yZSBmaW5lIGdyYWluZWQgZXhlY3V0aW9uIHdpdGhvdXQgaGF2aW5nIHRvIHJlbHkgb24gbXVsdGlwbGUgZGlmZmVyZW50IE9ic2VydmFibGUgb2JqZWN0cy5cbiAqIEZvciBpbnN0YW5jZSB5b3UgbWF5IGhhdmUgYSBnaXZlbiBPYnNlcnZhYmxlIHRoYXQgaGF2ZSBmb3VyIGRpZmZlcmVudCB0eXBlcyBvZiBub3RpZmljYXRpb25zOiBNb3ZlIChtYXNrID0gMHgwMSksIFN0b3AgKG1hc2sgPSAweDAyKSwgVHVybiBSaWdodCAobWFzayA9IDBYMDQpLCBUdXJuIExlZnQgKG1hc2sgPSAwWDA4KS5cbiAqIEEgZ2l2ZW4gb2JzZXJ2ZXIgY2FuIHJlZ2lzdGVyIGl0c2VsZiB3aXRoIG9ubHkgTW92ZSBhbmQgU3RvcCAobWFzayA9IDB4MDMpLCB0aGVuIGl0IHdpbGwgb25seSBiZSBub3RpZmllZCB3aGVuIG9uZSBvZiB0aGVzZSB0d28gb2NjdXJzIGFuZCB3aWxsIG5ldmVyIGJlIGZvciBUdXJuIExlZnQvUmlnaHQuXG4gKlxuICogQHB1YmxpY1xuICogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiBpcyBhbiBpbmhlcml0YW5jZSBvZiBFQ1M2LCBpdCdzIGhlcmUgdGVtcG9yYXJ5IGZvciB0aGUgZmVhdHVyZSBwYXJpdHksIHBsZWFzZSByZWFkIHRoZSBuZXdzIGFuZCBkb2NzIHRvIGtub3cgaG93IGhhbmRsZSB3aGVuIGl0J3MgcmVtb3ZlZFxuICovXG5leHBvcnQgY2xhc3MgT2JzZXJ2YWJsZTxUPiB7XG4gIHByaXZhdGUgX29ic2VydmVycyA9IG5ldyBBcnJheTxPYnNlcnZlcjxUPj4oKVxuXG4gIHByaXZhdGUgX2V2ZW50U3RhdGU6IE9ic2VydmVyRXZlbnRTdGF0ZVxuXG4gIHByaXZhdGUgX29uT2JzZXJ2ZXJBZGRlZDogbnVsbCB8ICgob2JzZXJ2ZXI6IE9ic2VydmVyPFQ+KSA9PiB2b2lkKSA9IG51bGxcblxuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBvYnNlcnZhYmxlXG4gICAqIEBwYXJhbSBvbk9ic2VydmVyQWRkZWQgLSBkZWZpbmVzIGEgY2FsbGJhY2sgdG8gY2FsbCB3aGVuIGEgbmV3IG9ic2VydmVyIGlzIGFkZGVkXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihvbk9ic2VydmVyQWRkZWQ/OiAob2JzZXJ2ZXI6IE9ic2VydmVyPFQ+KSA9PiB2b2lkKSB7XG4gICAgdGhpcy5fZXZlbnRTdGF0ZSA9IG5ldyBPYnNlcnZlckV2ZW50U3RhdGUoMClcblxuICAgIGlmIChvbk9ic2VydmVyQWRkZWQpIHtcbiAgICAgIHRoaXMuX29uT2JzZXJ2ZXJBZGRlZCA9IG9uT2JzZXJ2ZXJBZGRlZFxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSBuZXcgT2JzZXJ2ZXIgd2l0aCB0aGUgc3BlY2lmaWVkIGNhbGxiYWNrXG4gICAqIEBwYXJhbSBjYWxsYmFjayAtIHRoZSBjYWxsYmFjayB0aGF0IHdpbGwgYmUgZXhlY3V0ZWQgZm9yIHRoYXQgT2JzZXJ2ZXJcbiAgICogQHBhcmFtIG1hc2sgLSB0aGUgbWFzayB1c2VkIHRvIGZpbHRlciBvYnNlcnZlcnNcbiAgICogQHBhcmFtIGluc2VydEZpcnN0IC0gaWYgdHJ1ZSB0aGUgY2FsbGJhY2sgd2lsbCBiZSBpbnNlcnRlZCBhdCB0aGUgZmlyc3QgcG9zaXRpb24sIGhlbmNlIGV4ZWN1dGVkIGJlZm9yZSB0aGUgb3RoZXJzIG9uZXMuIElmIGZhbHNlIChkZWZhdWx0IGJlaGF2aW9yKSB0aGUgY2FsbGJhY2sgd2lsbCBiZSBpbnNlcnRlZCBhdCB0aGUgbGFzdCBwb3NpdGlvbiwgZXhlY3V0ZWQgYWZ0ZXIgYWxsIHRoZSBvdGhlcnMgYWxyZWFkeSBwcmVzZW50LlxuICAgKiBAcGFyYW0gc2NvcGUgLSBvcHRpb25hbCBzY29wZSBmb3IgdGhlIGNhbGxiYWNrIHRvIGJlIGNhbGxlZCBmcm9tXG4gICAqIEBwYXJhbSB1bnJlZ2lzdGVyT25GaXJzdENhbGwgLSBkZWZpbmVzIGlmIHRoZSBvYnNlcnZlciBhcyB0byBiZSB1bnJlZ2lzdGVyZWQgYWZ0ZXIgdGhlIG5leHQgbm90aWZpY2F0aW9uXG4gICAqIEByZXR1cm5zIHRoZSBuZXcgb2JzZXJ2ZXIgY3JlYXRlZCBmb3IgdGhlIGNhbGxiYWNrXG4gICAqL1xuICBwdWJsaWMgYWRkKFxuICAgIGNhbGxiYWNrOiAoZXZlbnREYXRhOiBULCBldmVudFN0YXRlOiBPYnNlcnZlckV2ZW50U3RhdGUpID0+IHZvaWQsXG4gICAgbWFzazogbnVtYmVyID0gLTEsXG4gICAgaW5zZXJ0Rmlyc3QgPSBmYWxzZSxcbiAgICBzY29wZTogYW55ID0gbnVsbCxcbiAgICB1bnJlZ2lzdGVyT25GaXJzdENhbGwgPSBmYWxzZVxuICApOiBudWxsIHwgT2JzZXJ2ZXI8VD4ge1xuICAgIGlmICghY2FsbGJhY2spIHtcbiAgICAgIHJldHVybiBudWxsXG4gICAgfVxuXG4gICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgT2JzZXJ2ZXIoY2FsbGJhY2ssIG1hc2ssIHNjb3BlKVxuICAgIG9ic2VydmVyLnVucmVnaXN0ZXJPbk5leHRDYWxsID0gdW5yZWdpc3Rlck9uRmlyc3RDYWxsXG5cbiAgICBpZiAoaW5zZXJ0Rmlyc3QpIHtcbiAgICAgIHRoaXMuX29ic2VydmVycy51bnNoaWZ0KG9ic2VydmVyKVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9vYnNlcnZlcnMucHVzaChvYnNlcnZlcilcbiAgICB9XG5cbiAgICBpZiAodGhpcy5fb25PYnNlcnZlckFkZGVkKSB7XG4gICAgICB0aGlzLl9vbk9ic2VydmVyQWRkZWQob2JzZXJ2ZXIpXG4gICAgfVxuXG4gICAgcmV0dXJuIG9ic2VydmVyXG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgbmV3IE9ic2VydmVyIHdpdGggdGhlIHNwZWNpZmllZCBjYWxsYmFjayBhbmQgdW5yZWdpc3RlcnMgYWZ0ZXIgdGhlIG5leHQgbm90aWZpY2F0aW9uXG4gICAqIEBwYXJhbSBjYWxsYmFjayAtIHRoZSBjYWxsYmFjayB0aGF0IHdpbGwgYmUgZXhlY3V0ZWQgZm9yIHRoYXQgT2JzZXJ2ZXJcbiAgICogQHJldHVybnMgdGhlIG5ldyBvYnNlcnZlciBjcmVhdGVkIGZvciB0aGUgY2FsbGJhY2tcbiAgICovXG4gIHB1YmxpYyBhZGRPbmNlKGNhbGxiYWNrOiAoZXZlbnREYXRhOiBULCBldmVudFN0YXRlOiBPYnNlcnZlckV2ZW50U3RhdGUpID0+IHZvaWQpOiBudWxsIHwgT2JzZXJ2ZXI8VD4ge1xuICAgIHJldHVybiB0aGlzLmFkZChjYWxsYmFjaywgdW5kZWZpbmVkLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdHJ1ZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmUgYW4gT2JzZXJ2ZXIgZnJvbSB0aGUgT2JzZXJ2YWJsZSBvYmplY3RcbiAgICogQHBhcmFtIG9ic2VydmVyIC0gdGhlIGluc3RhbmNlIG9mIHRoZSBPYnNlcnZlciB0byByZW1vdmVcbiAgICogQHJldHVybnMgZmFsc2UgaWYgaXQgZG9lc24ndCBiZWxvbmcgdG8gdGhpcyBPYnNlcnZhYmxlXG4gICAqL1xuICBwdWJsaWMgcmVtb3ZlKG9ic2VydmVyOiBudWxsIHwgT2JzZXJ2ZXI8VD4pOiBib29sZWFuIHtcbiAgICBpZiAoIW9ic2VydmVyKSB7XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG5cbiAgICBjb25zdCBpbmRleCA9IHRoaXMuX29ic2VydmVycy5pbmRleE9mKG9ic2VydmVyKVxuXG4gICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgdGhpcy5fZGVmZXJVbnJlZ2lzdGVyKG9ic2VydmVyKVxuICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmUgYSBjYWxsYmFjayBmcm9tIHRoZSBPYnNlcnZhYmxlIG9iamVjdFxuICAgKiBAcGFyYW0gY2FsbGJhY2sgLSB0aGUgY2FsbGJhY2sgdG8gcmVtb3ZlXG4gICAqIEBwYXJhbSBzY29wZSAtIG9wdGlvbmFsIHNjb3BlLiBJZiB1c2VkIG9ubHkgdGhlIGNhbGxiYWNrcyB3aXRoIHRoaXMgc2NvcGUgd2lsbCBiZSByZW1vdmVkXG4gICAqIEByZXR1cm5zIGZhbHNlIGlmIGl0IGRvZXNuJ3QgYmVsb25nIHRvIHRoaXMgT2JzZXJ2YWJsZVxuICAgKi9cbiAgcHVibGljIHJlbW92ZUNhbGxiYWNrKGNhbGxiYWNrOiAoZXZlbnREYXRhOiBULCBldmVudFN0YXRlOiBPYnNlcnZlckV2ZW50U3RhdGUpID0+IHZvaWQsIHNjb3BlPzogYW55KTogYm9vbGVhbiB7XG4gICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHRoaXMuX29ic2VydmVycy5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgIGlmICh0aGlzLl9vYnNlcnZlcnNbaW5kZXhdLmNhbGxiYWNrID09PSBjYWxsYmFjayAmJiAoIXNjb3BlIHx8IHNjb3BlID09PSB0aGlzLl9vYnNlcnZlcnNbaW5kZXhdLnNjb3BlKSkge1xuICAgICAgICB0aGlzLl9kZWZlclVucmVnaXN0ZXIodGhpcy5fb2JzZXJ2ZXJzW2luZGV4XSlcbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIC8qKlxuICAgKiBOb3RpZnkgYWxsIE9ic2VydmVycyBieSBjYWxsaW5nIHRoZWlyIHJlc3BlY3RpdmUgY2FsbGJhY2sgd2l0aCB0aGUgZ2l2ZW4gZGF0YVxuICAgKiBXaWxsIHJldHVybiB0cnVlIGlmIGFsbCBvYnNlcnZlcnMgd2VyZSBleGVjdXRlZCwgZmFsc2UgaWYgYW4gb2JzZXJ2ZXIgc2V0IHNraXBOZXh0T2JzZXJ2ZXJzIHRvIHRydWUsIHRoZW4gcHJldmVudCB0aGUgc3Vic2VxdWVudCBvbmVzIHRvIGV4ZWN1dGVcbiAgICogQHBhcmFtIGV2ZW50RGF0YSAtIGRlZmluZXMgdGhlIGRhdGEgdG8gc2VuZCB0byBhbGwgb2JzZXJ2ZXJzXG4gICAqIEBwYXJhbSBtYXNrIC0gZGVmaW5lcyB0aGUgbWFzayBvZiB0aGUgY3VycmVudCBub3RpZmljYXRpb24gKG9ic2VydmVycyB3aXRoIGluY29tcGF0aWJsZSBtYXNrIChpZSBtYXNrICYgb2JzZXJ2ZXIubWFzayA9PT0gMCkgd2lsbCBub3QgYmUgbm90aWZpZWQpXG4gICAqIEBwYXJhbSB0YXJnZXQgLSBkZWZpbmVzIHRoZSBvcmlnaW5hbCB0YXJnZXQgb2YgdGhlIHN0YXRlXG4gICAqIEBwYXJhbSBjdXJyZW50VGFyZ2V0IC0gZGVmaW5lcyB0aGUgY3VycmVudCB0YXJnZXQgb2YgdGhlIHN0YXRlXG4gICAqIEByZXR1cm5zIGZhbHNlIGlmIHRoZSBjb21wbGV0ZSBvYnNlcnZlciBjaGFpbiB3YXMgbm90IHByb2Nlc3NlZCAoYmVjYXVzZSBvbmUgb2JzZXJ2ZXIgc2V0IHRoZSBza2lwTmV4dE9ic2VydmVycyB0byB0cnVlKVxuICAgKi9cbiAgcHVibGljIG5vdGlmeU9ic2VydmVycyhldmVudERhdGE6IFQsIG1hc2s6IG51bWJlciA9IC0xLCB0YXJnZXQ/OiBhbnksIGN1cnJlbnRUYXJnZXQ/OiBhbnkpOiBib29sZWFuIHtcbiAgICBpZiAoIXRoaXMuX29ic2VydmVycy5sZW5ndGgpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLl9ldmVudFN0YXRlXG4gICAgc3RhdGUubWFzayA9IG1hc2tcbiAgICBzdGF0ZS50YXJnZXQgPSB0YXJnZXRcbiAgICBzdGF0ZS5jdXJyZW50VGFyZ2V0ID0gY3VycmVudFRhcmdldFxuICAgIHN0YXRlLnNraXBOZXh0T2JzZXJ2ZXJzID0gZmFsc2VcbiAgICBzdGF0ZS5sYXN0UmV0dXJuVmFsdWUgPSBldmVudERhdGFcblxuICAgIGZvciAoY29uc3Qgb2JzIG9mIHRoaXMuX29ic2VydmVycykge1xuICAgICAgaWYgKG9icy5fd2lsbEJlVW5yZWdpc3RlcmVkKSB7XG4gICAgICAgIGNvbnRpbnVlXG4gICAgICB9XG5cbiAgICAgIGlmIChvYnMubWFzayAmIG1hc2spIHtcbiAgICAgICAgaWYgKG9icy5zY29wZSkge1xuICAgICAgICAgIHN0YXRlLmxhc3RSZXR1cm5WYWx1ZSA9IG9icy5jYWxsYmFjay5hcHBseShvYnMuc2NvcGUsIFtldmVudERhdGEsIHN0YXRlXSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzdGF0ZS5sYXN0UmV0dXJuVmFsdWUgPSBvYnMuY2FsbGJhY2soZXZlbnREYXRhLCBzdGF0ZSlcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChvYnMudW5yZWdpc3Rlck9uTmV4dENhbGwpIHtcbiAgICAgICAgICB0aGlzLl9kZWZlclVucmVnaXN0ZXIob2JzKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoc3RhdGUuc2tpcE5leHRPYnNlcnZlcnMpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlXG4gIH1cblxuICAvKipcbiAgICogQ2FsbGluZyB0aGlzIHdpbGwgZXhlY3V0ZSBlYWNoIGNhbGxiYWNrLCBleHBlY3RpbmcgaXQgdG8gYmUgYSBwcm9taXNlIG9yIHJldHVybiBhIHZhbHVlLlxuICAgKiBJZiBhdCBhbnkgcG9pbnQgaW4gdGhlIGNoYWluIG9uZSBmdW5jdGlvbiBmYWlscywgdGhlIHByb21pc2Ugd2lsbCBmYWlsIGFuZCB0aGUgZXhlY3V0aW9uIHdpbGwgbm90IGNvbnRpbnVlLlxuICAgKiBUaGlzIGlzIHVzZWZ1bCB3aGVuIGEgY2hhaW4gb2YgZXZlbnRzIChzb21ldGltZXMgYXN5bmMgZXZlbnRzKSBpcyBuZWVkZWQgdG8gaW5pdGlhbGl6ZSBhIGNlcnRhaW4gb2JqZWN0XG4gICAqIGFuZCBpdCBpcyBjcnVjaWFsIHRoYXQgYWxsIGNhbGxiYWNrcyB3aWxsIGJlIGV4ZWN1dGVkLlxuICAgKiBUaGUgb3JkZXIgb2YgdGhlIGNhbGxiYWNrcyBpcyBrZXB0LCBjYWxsYmFja3MgYXJlIG5vdCBleGVjdXRlZCBwYXJhbGxlbC5cbiAgICpcbiAgICogQHBhcmFtIGV2ZW50RGF0YSAtIFRoZSBkYXRhIHRvIGJlIHNlbnQgdG8gZWFjaCBjYWxsYmFja1xuICAgKiBAcGFyYW0gbWFzayAtIGlzIHVzZWQgdG8gZmlsdGVyIG9ic2VydmVycyBkZWZhdWx0cyB0byAtMVxuICAgKiBAcGFyYW0gdGFyZ2V0IC0gZGVmaW5lcyB0aGUgY2FsbGJhY2sgdGFyZ2V0IChzZWUgRXZlbnRTdGF0ZSlcbiAgICogQHBhcmFtIGN1cnJlbnRUYXJnZXQgLSBkZWZpbmVzIGhlIGN1cnJlbnQgb2JqZWN0IGluIHRoZSBidWJibGluZyBwaGFzZVxuICAgKiBAcmV0dXJucyB3aWxsIHJldHVybiBhIFByb21pc2UgdGhhbiByZXNvbHZlcyB3aGVuIGFsbCBjYWxsYmFja3MgZXhlY3V0ZWQgc3VjY2Vzc2Z1bGx5LlxuICAgKi9cbiAgcHVibGljIG5vdGlmeU9ic2VydmVyc1dpdGhQcm9taXNlKGV2ZW50RGF0YTogVCwgbWFzazogbnVtYmVyID0gLTEsIHRhcmdldD86IGFueSwgY3VycmVudFRhcmdldD86IGFueSk6IFByb21pc2U8VD4ge1xuICAgIC8vIGNyZWF0ZSBhbiBlbXB0eSBwcm9taXNlXG4gICAgbGV0IHA6IFByb21pc2U8YW55PiA9IFByb21pc2UucmVzb2x2ZShldmVudERhdGEpXG5cbiAgICAvLyBubyBvYnNlcnZlcnM/IHJldHVybiB0aGlzIHByb21pc2UuXG4gICAgaWYgKCF0aGlzLl9vYnNlcnZlcnMubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gcFxuICAgIH1cblxuICAgIGNvbnN0IHN0YXRlID0gdGhpcy5fZXZlbnRTdGF0ZVxuICAgIHN0YXRlLm1hc2sgPSBtYXNrXG4gICAgc3RhdGUudGFyZ2V0ID0gdGFyZ2V0XG4gICAgc3RhdGUuY3VycmVudFRhcmdldCA9IGN1cnJlbnRUYXJnZXRcbiAgICBzdGF0ZS5za2lwTmV4dE9ic2VydmVycyA9IGZhbHNlXG5cbiAgICAvLyBleGVjdXRlIG9uZSBjYWxsYmFjayBhZnRlciBhbm90aGVyIChub3QgdXNpbmcgUHJvbWlzZS5hbGwsIHRoZSBvcmRlciBpcyBpbXBvcnRhbnQpXG4gICAgdGhpcy5fb2JzZXJ2ZXJzLmZvckVhY2goKG9icykgPT4ge1xuICAgICAgaWYgKHN0YXRlLnNraXBOZXh0T2JzZXJ2ZXJzKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgaWYgKG9icy5fd2lsbEJlVW5yZWdpc3RlcmVkKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgaWYgKG9icy5tYXNrICYgbWFzaykge1xuICAgICAgICBpZiAob2JzLnNjb3BlKSB7XG4gICAgICAgICAgcCA9IHAudGhlbigobGFzdFJldHVybmVkVmFsdWUpID0+IHtcbiAgICAgICAgICAgIHN0YXRlLmxhc3RSZXR1cm5WYWx1ZSA9IGxhc3RSZXR1cm5lZFZhbHVlXG4gICAgICAgICAgICByZXR1cm4gb2JzLmNhbGxiYWNrLmFwcGx5KG9icy5zY29wZSwgW2V2ZW50RGF0YSwgc3RhdGVdKVxuICAgICAgICAgIH0pXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcCA9IHAudGhlbigobGFzdFJldHVybmVkVmFsdWUpID0+IHtcbiAgICAgICAgICAgIHN0YXRlLmxhc3RSZXR1cm5WYWx1ZSA9IGxhc3RSZXR1cm5lZFZhbHVlXG4gICAgICAgICAgICByZXR1cm4gb2JzLmNhbGxiYWNrKGV2ZW50RGF0YSwgc3RhdGUpXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgICBpZiAob2JzLnVucmVnaXN0ZXJPbk5leHRDYWxsKSB7XG4gICAgICAgICAgdGhpcy5fZGVmZXJVbnJlZ2lzdGVyKG9icylcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG5cbiAgICAvLyByZXR1cm4gdGhlIGV2ZW50RGF0YVxuICAgIHJldHVybiBwLnRoZW4oKCkgPT4ge1xuICAgICAgcmV0dXJuIGV2ZW50RGF0YVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogTm90aWZ5IGEgc3BlY2lmaWMgb2JzZXJ2ZXJcbiAgICogQHBhcmFtIG9ic2VydmVyIC0gZGVmaW5lcyB0aGUgb2JzZXJ2ZXIgdG8gbm90aWZ5XG4gICAqIEBwYXJhbSBldmVudERhdGEgLSBkZWZpbmVzIHRoZSBkYXRhIHRvIGJlIHNlbnQgdG8gZWFjaCBjYWxsYmFja1xuICAgKiBAcGFyYW0gbWFzayAtIGlzIHVzZWQgdG8gZmlsdGVyIG9ic2VydmVycyBkZWZhdWx0cyB0byAtMVxuICAgKi9cbiAgcHVibGljIG5vdGlmeU9ic2VydmVyKG9ic2VydmVyOiBPYnNlcnZlcjxUPiwgZXZlbnREYXRhOiBULCBtYXNrOiBudW1iZXIgPSAtMSk6IHZvaWQge1xuICAgIGNvbnN0IHN0YXRlID0gdGhpcy5fZXZlbnRTdGF0ZVxuICAgIHN0YXRlLm1hc2sgPSBtYXNrXG4gICAgc3RhdGUuc2tpcE5leHRPYnNlcnZlcnMgPSBmYWxzZVxuXG4gICAgb2JzZXJ2ZXIuY2FsbGJhY2soZXZlbnREYXRhLCBzdGF0ZSlcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXRzIGEgYm9vbGVhbiBpbmRpY2F0aW5nIGlmIHRoZSBvYnNlcnZhYmxlIGhhcyBhdCBsZWFzdCBvbmUgb2JzZXJ2ZXJcbiAgICogQHJldHVybnMgdHJ1ZSBpcyB0aGUgT2JzZXJ2YWJsZSBoYXMgYXQgbGVhc3Qgb25lIE9ic2VydmVyIHJlZ2lzdGVyZWRcbiAgICovXG4gIHB1YmxpYyBoYXNPYnNlcnZlcnMoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuX29ic2VydmVycy5sZW5ndGggPiAwXG4gIH1cblxuICAvKipcbiAgICogQ2xlYXIgdGhlIGxpc3Qgb2Ygb2JzZXJ2ZXJzXG4gICAqL1xuICBwdWJsaWMgY2xlYXIoKTogdm9pZCB7XG4gICAgdGhpcy5fb2JzZXJ2ZXJzID0gbmV3IEFycmF5PE9ic2VydmVyPFQ+PigpXG4gICAgdGhpcy5fb25PYnNlcnZlckFkZGVkID0gbnVsbFxuICB9XG5cbiAgLyoqXG4gICAqIENsb25lIHRoZSBjdXJyZW50IG9ic2VydmFibGVcbiAgICogQHJldHVybnMgYSBuZXcgb2JzZXJ2YWJsZVxuICAgKi9cbiAgcHVibGljIGNsb25lKCk6IE9ic2VydmFibGU8VD4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBPYnNlcnZhYmxlPFQ+KClcblxuICAgIHJlc3VsdC5fb2JzZXJ2ZXJzID0gdGhpcy5fb2JzZXJ2ZXJzLnNsaWNlKDApXG5cbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cblxuICAvKipcbiAgICogRG9lcyB0aGlzIG9ic2VydmFibGUgaGFuZGxlcyBvYnNlcnZlciByZWdpc3RlcmVkIHdpdGggYSBnaXZlbiBtYXNrXG4gICAqIEBwYXJhbSBtYXNrIC0gZGVmaW5lcyB0aGUgbWFzayB0byBiZSB0ZXN0ZWRcbiAgICogQHJldHVybnMgd2hldGhlciBvciBub3Qgb25lIG9ic2VydmVyIHJlZ2lzdGVyZWQgd2l0aCB0aGUgZ2l2ZW4gbWFzayBpcyBoYW5kZWxlZFxuICAgKi9cbiAgcHVibGljIGhhc1NwZWNpZmljTWFzayhtYXNrOiBudW1iZXIgPSAtMSk6IGJvb2xlYW4ge1xuICAgIGZvciAoY29uc3Qgb2JzIG9mIHRoaXMuX29ic2VydmVycykge1xuICAgICAgaWYgKG9icy5tYXNrICYgbWFzayB8fCBvYnMubWFzayA9PT0gbWFzaykge1xuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIHByaXZhdGUgX2RlZmVyVW5yZWdpc3RlcihvYnNlcnZlcjogT2JzZXJ2ZXI8VD4pOiB2b2lkIHtcbiAgICBvYnNlcnZlci51bnJlZ2lzdGVyT25OZXh0Q2FsbCA9IGZhbHNlXG4gICAgb2JzZXJ2ZXIuX3dpbGxCZVVucmVnaXN0ZXJlZCA9IHRydWVcbiAgICBQcm9taXNlLnJlc29sdmUoKVxuICAgICAgLnRoZW4uYmluZChQcm9taXNlLnJlc29sdmUoKSkoYXN5bmMgKCkgPT4gdGhpcy5fcmVtb3ZlKG9ic2VydmVyKSlcbiAgICAgIC5jYXRjaChjb25zb2xlLmVycm9yKVxuICB9XG5cbiAgLy8gVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgd2hlbiBub3QgaXRlcmF0aW5nIG92ZXIgX29ic2VydmVycyB0byBhdm9pZCBjYWxsYmFjayBza2lwcGluZy5cbiAgLy8gUmVtb3ZlcyBhbiBvYnNlcnZlciBmcm9tIHRoZSBfb2JzZXJ2ZXIgQXJyYXkuXG4gIHByaXZhdGUgX3JlbW92ZShvYnNlcnZlcjogbnVsbCB8IE9ic2VydmVyPFQ+KTogYm9vbGVhbiB7XG4gICAgaWYgKCFvYnNlcnZlcikge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuXG4gICAgY29uc3QgaW5kZXggPSB0aGlzLl9vYnNlcnZlcnMuaW5kZXhPZihvYnNlcnZlcilcblxuICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgIHRoaXMuX29ic2VydmVycy5zcGxpY2UoaW5kZXgsIDEpXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cblxuICAgIHJldHVybiBmYWxzZVxuICB9XG59XG4iXX0=