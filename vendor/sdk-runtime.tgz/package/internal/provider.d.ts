export interface SendAsyncResponse {
    jsonAnyResponse: string;
}
export interface SendAsyncRequest {
    id: number;
    method: string;
    jsonParams: string;
}
export type RPCSendableMessage = {
    jsonrpc: '2.0';
    id: number;
    method: string;
    params: any[];
};
export interface MessageDict {
    [key: string]: string;
}
export type SendAsyncType = (params: SendAsyncRequest) => Promise<SendAsyncResponse>;
export declare function getEthereumProvider(sendAsync: SendAsyncType): {
    send(message: RPCSendableMessage, callback?: ((error: Error | null, result?: any) => void) | undefined): void;
    sendAsync(message: RPCSendableMessage, callback: (error: Error | null, result?: any) => void): void;
};
