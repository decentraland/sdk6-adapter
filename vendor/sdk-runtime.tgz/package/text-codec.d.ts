export declare class TextEncoder {
    readonly encoding = "utf-8";
    encode(input?: string): Uint8Array;
    encodeInto(source: string, destination: Uint8Array): {
        read: number;
        written: number;
    };
}
export declare class TextDecoder {
    readonly encoding = "utf-8";
    readonly fatal: boolean;
    readonly ignoreBOM: boolean;
    constructor(label?: string, options?: {
        fatal?: boolean;
        ignoreBOM?: boolean;
    });
    decode(input?: ArrayBuffer | ArrayBufferView, options?: {
        stream?: boolean;
    }): string;
}
/**
 * Install `TextEncoder` / `TextDecoder` on `globalThis` where the runtime does
 * not provide them (native implementations always win over these polyfills).
 *
 * Exposed from the lean `@dcl/sdk/text-codec` subpath so consumers can install
 * the polyfill without pulling in the ethereum provider.
 */
export declare function polyfillTextEncoder(): void;
