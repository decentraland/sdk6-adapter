import { Observable } from './internal/Observable';
import { Vector3Type } from '@dcl/ecs';
/** @public */
export type IEventNames = keyof IEvents;
/**
 * @public
 * Note: Don't use `on` prefix for IEvents to avoid redundancy with `event.on("onEventName")` syntax.
 */
export interface IEvents {
    playerExpression: {
        expressionId: string;
    };
    /**
     * This event gets triggered when the user enters the scene
     */
    onEnterScene: {
        userId: string;
    };
    /**
     * This event gets triggered when the user leaves the scene
     */
    onLeaveScene: {
        userId: string;
    };
    /**
     * This event gets triggered after receiving a comms message.
     */
    comms: {
        sender: string;
        message: string;
    };
    /**
     * This is triggered once the scene should start.
     */
    sceneStart: unknown;
    /** This is triggered at least for each videoStatus change */
    videoEvent: {
        componentId: string;
        videoClipId: string;
        /** Status, can be NONE = 0, ERROR = 1, LOADING = 2, READY = 3, PLAYING = 4,BUFFERING = 5 */
        videoStatus: number;
        /** Current offset position in seconds */
        currentOffset: number;
        /** Video length in seconds. Can be -1 */
        totalVideoLength: number;
    };
    /** This is trigger everytime a profile is changed */
    profileChanged: {
        ethAddress: string;
        version: number;
    };
    /** Triggered when peer's avatar is connected and visible */
    playerConnected: {
        userId: string;
    };
    /** Triggered when peer disconnect and/or it avatar is set invisible by comms */
    playerDisconnected: {
        userId: string;
    };
    /** Triggered when current realm or island changes */
    onRealmChanged: {
        domain: string;
        room: string;
        serverName: string;
        displayName: string;
    };
    /** Triggered when other player's avatar is clicked */
    playerClicked: {
        userId: string;
        ray: {
            origin: Vector3Type;
            direction: Vector3Type;
            distance: number;
        };
    };
}
/**
 * These events are triggered after your character enters the scene.
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onEnterSceneObservable: Observable<{
    userId: string;
}>;
/** @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed. Use onEnterSceneObservable instead. */
export declare const onEnterScene: Observable<{
    userId: string;
}>;
/**
 * These events are triggered after your character leaves the scene.
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onLeaveSceneObservable: Observable<{
    userId: string;
}>;
/** @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed. Use onLeaveSceneObservable instead. */
export declare const onLeaveScene: Observable<{
    userId: string;
}>;
/**
 * This event is triggered after all the resources of the scene were loaded (models, textures, etc...)
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onSceneReadyObservable: Observable<unknown>;
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onPlayerExpressionObservable: Observable<{
    expressionId: string;
}>;
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onVideoEvent: Observable<{
    componentId: string;
    videoClipId: string;
    /** Status, can be NONE = 0, ERROR = 1, LOADING = 2, READY = 3, PLAYING = 4,BUFFERING = 5 */
    videoStatus: number;
    /** Current offset position in seconds */
    currentOffset: number;
    /** Video length in seconds. Can be -1 */
    totalVideoLength: number;
}>;
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onProfileChanged: Observable<{
    ethAddress: string;
    version: number;
}>;
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onPlayerConnectedObservable: Observable<{
    userId: string;
}>;
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onPlayerDisconnectedObservable: Observable<{
    userId: string;
}>;
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onRealmChangedObservable: Observable<{
    domain: string;
    room: string;
    serverName: string;
    displayName: string;
}>;
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export declare const onPlayerClickedObservable: Observable<{
    userId: string;
    ray: {
        origin: Vector3Type;
        direction: Vector3Type;
        distance: number;
    };
}>;
