export type Platform = 'mobile' | 'desktop' | 'web';
export declare function getPlatform(): Platform | null;
export declare function isMobile(): boolean;
export declare function isDesktop(): boolean;
export declare function isWeb(): boolean;
