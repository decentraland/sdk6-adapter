import { Observer } from './internal/Observable';
import { IEvents } from './observables';
/**
 * @alpha
 * @deprecated this will only exist for a few releases in ECS7
 */
export declare class MessageBus {
    private messageQueue;
    private flushing;
    constructor();
    on(message: string, callback: (value: any, sender: string) => void): Observer<IEvents['comms']>;
    emit(message: string, payload: Record<any, any>): void;
    private flush;
}
