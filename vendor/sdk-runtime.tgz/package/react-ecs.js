/**
 * The module react-ecs is exposed by the sdk in the /react-ecs path.
 *
 * UI components and semantics for the SDK 7.
 *
 * JSX & Flexbox is used due to its market adoption and availability of implementations and documentation and expertise.
 * @example
 * ```tsx
 * import ReactEcs, { Label, ReactEcsRenderer } from '@dcl/sdk/react-ecs'
 * const Ui = () => <Label value="SDK 7" />
 * ReactEcsRenderer.setUiRenderer(ui)
 * ```
 *
 *
 * Go to the Function section to see all the UI Components.
 * @module ReactEcs
 *
 */
import ReactEcs from '@dcl/react-ecs';
import { setIsMobileProvider } from '@dcl/react-ecs/dist/platform';
import { isMobile } from './platform';
// react-ecs cannot reach ~system/Runtime itself, so the platform check used
// for virtual screen size defaults is injected here.
setIsMobileProvider(isMobile);
export * from '@dcl/react-ecs';
export default ReactEcs;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtZWNzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic3JjL3JlYWN0LWVjcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FpQkc7QUFFSCxPQUFPLFFBQVEsTUFBTSxnQkFBZ0IsQ0FBQTtBQUNyQyxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQTtBQUNsRSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sWUFBWSxDQUFBO0FBRXJDLDRFQUE0RTtBQUM1RSxxREFBcUQ7QUFDckQsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUE7QUFFN0IsY0FBYyxnQkFBZ0IsQ0FBQTtBQUM5QixlQUFlLFFBQVEsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogVGhlIG1vZHVsZSByZWFjdC1lY3MgaXMgZXhwb3NlZCBieSB0aGUgc2RrIGluIHRoZSAvcmVhY3QtZWNzIHBhdGguXG4gKlxuICogVUkgY29tcG9uZW50cyBhbmQgc2VtYW50aWNzIGZvciB0aGUgU0RLIDcuXG4gKlxuICogSlNYICYgRmxleGJveCBpcyB1c2VkIGR1ZSB0byBpdHMgbWFya2V0IGFkb3B0aW9uIGFuZCBhdmFpbGFiaWxpdHkgb2YgaW1wbGVtZW50YXRpb25zIGFuZCBkb2N1bWVudGF0aW9uIGFuZCBleHBlcnRpc2UuXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBpbXBvcnQgUmVhY3RFY3MsIHsgTGFiZWwsIFJlYWN0RWNzUmVuZGVyZXIgfSBmcm9tICdAZGNsL3Nkay9yZWFjdC1lY3MnXG4gKiBjb25zdCBVaSA9ICgpID0+IDxMYWJlbCB2YWx1ZT1cIlNESyA3XCIgLz5cbiAqIFJlYWN0RWNzUmVuZGVyZXIuc2V0VWlSZW5kZXJlcih1aSlcbiAqIGBgYFxuICpcbiAqXG4gKiBHbyB0byB0aGUgRnVuY3Rpb24gc2VjdGlvbiB0byBzZWUgYWxsIHRoZSBVSSBDb21wb25lbnRzLlxuICogQG1vZHVsZSBSZWFjdEVjc1xuICpcbiAqL1xuXG5pbXBvcnQgUmVhY3RFY3MgZnJvbSAnQGRjbC9yZWFjdC1lY3MnXG5pbXBvcnQgeyBzZXRJc01vYmlsZVByb3ZpZGVyIH0gZnJvbSAnQGRjbC9yZWFjdC1lY3MvZGlzdC9wbGF0Zm9ybSdcbmltcG9ydCB7IGlzTW9iaWxlIH0gZnJvbSAnLi9wbGF0Zm9ybSdcblxuLy8gcmVhY3QtZWNzIGNhbm5vdCByZWFjaCB+c3lzdGVtL1J1bnRpbWUgaXRzZWxmLCBzbyB0aGUgcGxhdGZvcm0gY2hlY2sgdXNlZFxuLy8gZm9yIHZpcnR1YWwgc2NyZWVuIHNpemUgZGVmYXVsdHMgaXMgaW5qZWN0ZWQgaGVyZS5cbnNldElzTW9iaWxlUHJvdmlkZXIoaXNNb2JpbGUpXG5cbmV4cG9ydCAqIGZyb20gJ0BkY2wvcmVhY3QtZWNzJ1xuZXhwb3J0IGRlZmF1bHQgUmVhY3RFY3NcbiJdfQ==