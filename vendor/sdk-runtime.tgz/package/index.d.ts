export declare function onUpdate(deltaTime: number): Promise<void>;
