/**
 * This module provides a createTestRuntime function that returns an object with a test function that can be used to define tests.
 */
import { IEngine } from '@dcl/ecs';
import type { TestingModule, TestFunction } from './types';
export declare function createTestRuntime(testingModule: TestingModule, engine: IEngine): {
    test: (name: string, fn: TestFunction) => void;
};
