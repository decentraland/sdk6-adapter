/**
 * This module provides a createTestRuntime function that returns an object with a test function that can be used to define tests.
 */
import { Transform } from '@dcl/ecs';
import { assertEquals } from './assert';
// This function creates a test runtime that can be used to define and run tests.
// It takes a `TestingModule` instance (loaded from require('~system/Testing')) and an `IEngine` instance (from Decentraland's SDK).
// It returns an object with a `test` function that can be used to define tests.
/* @__PURE__ */
export function createTestRuntime(testingModule, engine) {
    // this flag ensures no tests are added asynchronously
    let runtimeFrozen = false;
    let currentFrameCounter = 0;
    let currentFrameTime = 0;
    // array to hold the scheduled tests
    const scheduledTests = [];
    // an array of promises that are resolved on the next frame (after the current frame is finished)
    const nextTickFuture = [];
    // this function returns a promise that resolves on the next frame
    async function nextTick() {
        return new Promise((resolve) => {
            nextTickFuture.push(resolve);
        });
    }
    // add a system to the engine that resolves all promises in the `nextTickFuture` array
    engine.addSystem(function TestingFrameworkCoroutineRunner(dt) {
        currentFrameCounter++;
        currentFrameTime += dt;
        // resolve all nextTick futures.
        nextTickFuture.splice(0, nextTickFuture.length).forEach((_) => _(dt));
    });
    // this function schedules a value to be processed on the next frame, the test runner will
    // continue to run until it reaches a yield point
    function scheduleValue(value, env) {
        if (value && typeof value === 'object' && typeof value.then === 'function') {
            console.log('⏱️ yield promise');
            // if the value is a promise, schedule it to be awaited after the current frame is finished
            nextTickFuture.push(async () => {
                try {
                    scheduleValue(await value, env);
                }
                catch (err) {
                    env.reject(err);
                }
            });
        }
        else if (typeof value === 'function') {
            console.log('⏱️ yield function');
            // if the value is a function, schedule it to be called on the next frame
            nextTickFuture.push(() => {
                scheduleValue(value(), env);
            });
            return;
        }
        else if (typeof value === 'undefined' || value === null) {
            console.log('⏱️ yield');
            // if the value is undefined or null, continue processing the generator the next frame
            nextTickFuture.push(() => {
                consumeGenerator(env);
            });
        }
        else
            throw new Error(`Unexpected value from test generator: ${value}`);
    }
    // this function processes a generator function by scheduling its values to be processed on the next frame
    function consumeGenerator(env) {
        try {
            const ret = env.generator.next();
            if (!ret.done) {
                scheduleValue(ret.value, env);
            }
            else {
                env.resolve();
            }
        }
        catch (err) {
            env.reject(err);
        }
    }
    // this function schedules a test run on the next frame
    function scheduleNextRun() {
        if (scheduledTests.length) {
            nextTickFuture.push(runTests);
        }
    }
    // this function runs the scheduled tests
    function runTests() {
        if (scheduledTests.length) {
            const entry = scheduledTests.shift();
            const initialFrame = currentFrameCounter;
            const startTime = currentFrameTime;
            let resolved = false;
            // this function should be called only once. it makes the current test pass
            const resolve = () => {
                if (resolved)
                    throw new Error('resolved twice');
                resolved = true;
                console.log(`🟢 Test passed ${entry.name}`);
                testingModule
                    .logTestResult({
                    name: entry.name,
                    ok: true,
                    totalFrames: currentFrameCounter - initialFrame,
                    totalTime: currentFrameTime - startTime
                })
                    .finally(scheduleNextRun);
            };
            const reject = (err) => {
                if (resolved)
                    throw new Error('resolved twice');
                resolved = true;
                console.log(`🔴 Test failed ${entry.name}`);
                console.error(err);
                testingModule
                    .logTestResult({
                    name: entry.name,
                    ok: false,
                    error: err.toString(),
                    stack: err && typeof err === 'object' && err.stack,
                    totalFrames: currentFrameCounter - initialFrame,
                    totalTime: currentFrameTime - startTime
                })
                    .finally(scheduleNextRun);
            };
            try {
                console.log(`🧪 Running test ${entry.name}`);
                const testHelpers = {
                    async setCameraTransform(transform) {
                        await testingModule.setCameraTransform(transform);
                        await nextTick();
                        const TransformComponent = engine.getComponent(Transform.componentId);
                        const actualTransform = TransformComponent.get(engine.CameraEntity);
                        assertEquals(actualTransform.position, transform.position, "positions don't match");
                        assertEquals(actualTransform.rotation, transform.rotation, "rotations don't match");
                    }
                };
                const returnValue = entry.fn(testHelpers);
                if (returnValue && typeof returnValue === 'object') {
                    if (isGenerator(returnValue)) {
                        const env = {
                            generator: returnValue,
                            helpers: testHelpers,
                            resolve,
                            reject
                        };
                        consumeGenerator(env);
                    }
                    else if (isPromise(returnValue)) {
                        returnValue.then(resolve).catch(reject);
                    }
                    else {
                        throw new Error(`Unknown test result type: ${returnValue}`);
                    }
                }
                else {
                    resolve();
                }
            }
            catch (err) {
                reject(err);
            }
        }
    }
    // schedule the test runner start for the next frame
    nextTickFuture.push(() => {
        // once we run the next tick, the test runtime becomes frozen. that means no new
        // test definitions are accepted
        runtimeFrozen = true;
        if (!scheduledTests.length)
            return;
        // inform the test runner about the plans for this test run
        testingModule.plan({ tests: scheduledTests }).then(scheduleNextRun).catch(globalFail);
    });
    // this is the function that is used to plan a test functionn
    /* @__PURE__ */
    function test(name, fn) {
        if (runtimeFrozen)
            throw new Error("New tests can't be added at this stage.");
        if (scheduledTests.some(($) => $.name === name))
            throw new Error(`Test with name ${name} already exists`);
        scheduledTests.push({ fn, name });
    }
    return {
        test
    };
}
function isGenerator(t) {
    return t && typeof t === 'object' && typeof t[Symbol.iterator] === 'function';
}
function isPromise(t) {
    return t && typeof t === 'object' && typeof t.then === 'function';
}
function globalFail(error) {
    // for now, the failure is only writing to the console.error.
    console.error(error);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicnVudGltZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3NyYy90ZXN0aW5nL3J1bnRpbWUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0dBRUc7QUFFSCxPQUFPLEVBQVcsU0FBUyxFQUFFLE1BQU0sVUFBVSxDQUFBO0FBQzdDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxVQUFVLENBQUE7QUFHdkMsaUZBQWlGO0FBQ2pGLG9JQUFvSTtBQUNwSSxnRkFBZ0Y7QUFDaEYsZUFBZTtBQUNmLE1BQU0sVUFBVSxpQkFBaUIsQ0FBQyxhQUE0QixFQUFFLE1BQWU7SUFTN0Usc0RBQXNEO0lBQ3RELElBQUksYUFBYSxHQUFHLEtBQUssQ0FBQTtJQUV6QixJQUFJLG1CQUFtQixHQUFHLENBQUMsQ0FBQTtJQUMzQixJQUFJLGdCQUFnQixHQUFHLENBQUMsQ0FBQTtJQUV4QixvQ0FBb0M7SUFDcEMsTUFBTSxjQUFjLEdBQW9CLEVBQUUsQ0FBQTtJQUUxQyxpR0FBaUc7SUFDakcsTUFBTSxjQUFjLEdBQWdDLEVBQUUsQ0FBQTtJQUV0RCxrRUFBa0U7SUFDbEUsS0FBSyxVQUFVLFFBQVE7UUFDckIsT0FBTyxJQUFJLE9BQU8sQ0FBUyxDQUFDLE9BQU8sRUFBRSxFQUFFO1lBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDOUIsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsc0ZBQXNGO0lBQ3RGLE1BQU0sQ0FBQyxTQUFTLENBQUMsU0FBUywrQkFBK0IsQ0FBQyxFQUFFO1FBQzFELG1CQUFtQixFQUFFLENBQUE7UUFDckIsZ0JBQWdCLElBQUksRUFBRSxDQUFBO1FBQ3RCLGdDQUFnQztRQUNoQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtJQUN2RSxDQUFDLENBQUMsQ0FBQTtJQUVGLDBGQUEwRjtJQUMxRixpREFBaUQ7SUFDakQsU0FBUyxhQUFhLENBQUMsS0FBVSxFQUFFLEdBQXNCO1FBQ3ZELElBQUksS0FBSyxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxPQUFPLEtBQUssQ0FBQyxJQUFJLEtBQUssVUFBVSxFQUFFO1lBQzFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQTtZQUMvQiwyRkFBMkY7WUFDM0YsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRTtnQkFDN0IsSUFBSTtvQkFDRixhQUFhLENBQUMsTUFBTSxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUE7aUJBQ2hDO2dCQUFDLE9BQU8sR0FBRyxFQUFFO29CQUNaLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7aUJBQ2hCO1lBQ0gsQ0FBQyxDQUFDLENBQUE7U0FDSDthQUFNLElBQUksT0FBTyxLQUFLLEtBQUssVUFBVSxFQUFFO1lBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQTtZQUNoQyx5RUFBeUU7WUFDekUsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ3ZCLGFBQWEsQ0FBQyxLQUFLLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQTtZQUM3QixDQUFDLENBQUMsQ0FBQTtZQUNGLE9BQU07U0FDUDthQUFNLElBQUksT0FBTyxLQUFLLEtBQUssV0FBVyxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7WUFDekQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQTtZQUN2QixzRkFBc0Y7WUFDdEYsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7Z0JBQ3ZCLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFBO1lBQ3ZCLENBQUMsQ0FBQyxDQUFBO1NBQ0g7O1lBQU0sTUFBTSxJQUFJLEtBQUssQ0FBQyx5Q0FBeUMsS0FBSyxFQUFFLENBQUMsQ0FBQTtJQUMxRSxDQUFDO0lBRUQsMEdBQTBHO0lBQzFHLFNBQVMsZ0JBQWdCLENBQUMsR0FBc0I7UUFDOUMsSUFBSTtZQUNGLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUE7WUFDaEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUU7Z0JBQ2IsYUFBYSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUE7YUFDOUI7aUJBQU07Z0JBQ0wsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFBO2FBQ2Q7U0FDRjtRQUFDLE9BQU8sR0FBRyxFQUFFO1lBQ1osR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQTtTQUNoQjtJQUNILENBQUM7SUFFRCx1REFBdUQ7SUFDdkQsU0FBUyxlQUFlO1FBQ3RCLElBQUksY0FBYyxDQUFDLE1BQU0sRUFBRTtZQUN6QixjQUFjLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1NBQzlCO0lBQ0gsQ0FBQztJQUVELHlDQUF5QztJQUN6QyxTQUFTLFFBQVE7UUFDZixJQUFJLGNBQWMsQ0FBQyxNQUFNLEVBQUU7WUFDekIsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLEtBQUssRUFBRyxDQUFBO1lBQ3JDLE1BQU0sWUFBWSxHQUFHLG1CQUFtQixDQUFBO1lBQ3hDLE1BQU0sU0FBUyxHQUFHLGdCQUFnQixDQUFBO1lBRWxDLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQTtZQUVwQiwyRUFBMkU7WUFDM0UsTUFBTSxPQUFPLEdBQUcsR0FBRyxFQUFFO2dCQUNuQixJQUFJLFFBQVE7b0JBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO2dCQUMvQyxRQUFRLEdBQUcsSUFBSSxDQUFBO2dCQUVmLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFBO2dCQUUzQyxhQUFhO3FCQUNWLGFBQWEsQ0FBQztvQkFDYixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7b0JBQ2hCLEVBQUUsRUFBRSxJQUFJO29CQUNSLFdBQVcsRUFBRSxtQkFBbUIsR0FBRyxZQUFZO29CQUMvQyxTQUFTLEVBQUUsZ0JBQWdCLEdBQUcsU0FBUztpQkFDeEMsQ0FBQztxQkFDRCxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUE7WUFDN0IsQ0FBQyxDQUFBO1lBRUQsTUFBTSxNQUFNLEdBQUcsQ0FBQyxHQUFRLEVBQUUsRUFBRTtnQkFDMUIsSUFBSSxRQUFRO29CQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtnQkFDL0MsUUFBUSxHQUFHLElBQUksQ0FBQTtnQkFFZixPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQTtnQkFDM0MsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQTtnQkFFbEIsYUFBYTtxQkFDVixhQUFhLENBQUM7b0JBQ2IsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJO29CQUNoQixFQUFFLEVBQUUsS0FBSztvQkFDVCxLQUFLLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRTtvQkFDckIsS0FBSyxFQUFFLEdBQUcsSUFBSSxPQUFPLEdBQUcsS0FBSyxRQUFRLElBQUksR0FBRyxDQUFDLEtBQUs7b0JBQ2xELFdBQVcsRUFBRSxtQkFBbUIsR0FBRyxZQUFZO29CQUMvQyxTQUFTLEVBQUUsZ0JBQWdCLEdBQUcsU0FBUztpQkFDeEMsQ0FBQztxQkFDRCxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUE7WUFDN0IsQ0FBQyxDQUFBO1lBRUQsSUFBSTtnQkFDRixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQTtnQkFFNUMsTUFBTSxXQUFXLEdBQWdCO29CQUMvQixLQUFLLENBQUMsa0JBQWtCLENBQUMsU0FBUzt3QkFDaEMsTUFBTSxhQUFhLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUE7d0JBQ2pELE1BQU0sUUFBUSxFQUFFLENBQUE7d0JBRWhCLE1BQU0sa0JBQWtCLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFxQixDQUFBO3dCQUN6RixNQUFNLGVBQWUsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFBO3dCQUVuRSxZQUFZLENBQUMsZUFBZSxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsUUFBUSxFQUFFLHVCQUF1QixDQUFDLENBQUE7d0JBQ25GLFlBQVksQ0FBQyxlQUFlLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxRQUFRLEVBQUUsdUJBQXVCLENBQUMsQ0FBQTtvQkFDckYsQ0FBQztpQkFDRixDQUFBO2dCQUVELE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUE7Z0JBRXpDLElBQUksV0FBVyxJQUFJLE9BQU8sV0FBVyxLQUFLLFFBQVEsRUFBRTtvQkFDbEQsSUFBSSxXQUFXLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQzVCLE1BQU0sR0FBRyxHQUFzQjs0QkFDN0IsU0FBUyxFQUFFLFdBQVc7NEJBQ3RCLE9BQU8sRUFBRSxXQUFXOzRCQUNwQixPQUFPOzRCQUNQLE1BQU07eUJBQ1AsQ0FBQTt3QkFDRCxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQTtxQkFDdEI7eUJBQU0sSUFBSSxTQUFTLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ2pDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFBO3FCQUN4Qzt5QkFBTTt3QkFDTCxNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixXQUFXLEVBQUUsQ0FBQyxDQUFBO3FCQUM1RDtpQkFDRjtxQkFBTTtvQkFDTCxPQUFPLEVBQUUsQ0FBQTtpQkFDVjthQUNGO1lBQUMsT0FBTyxHQUFRLEVBQUU7Z0JBQ2pCLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQTthQUNaO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsb0RBQW9EO0lBQ3BELGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ3ZCLGdGQUFnRjtRQUNoRixnQ0FBZ0M7UUFDaEMsYUFBYSxHQUFHLElBQUksQ0FBQTtRQUVwQixJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU07WUFBRSxPQUFNO1FBRWxDLDJEQUEyRDtRQUMzRCxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQTtJQUN2RixDQUFDLENBQUMsQ0FBQTtJQUVGLDZEQUE2RDtJQUM3RCxlQUFlO0lBQ2YsU0FBUyxJQUFJLENBQUMsSUFBWSxFQUFFLEVBQWdCO1FBQzFDLElBQUksYUFBYTtZQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMseUNBQXlDLENBQUMsQ0FBQTtRQUU3RSxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDO1lBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsSUFBSSxpQkFBaUIsQ0FBQyxDQUFBO1FBRXpHLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtJQUNuQyxDQUFDO0lBRUQsT0FBTztRQUNMLElBQUk7S0FDTCxDQUFBO0FBQ0gsQ0FBQztBQUVELFNBQVMsV0FBVyxDQUFDLENBQU07SUFDekIsT0FBTyxDQUFDLElBQUksT0FBTyxDQUFDLEtBQUssUUFBUSxJQUFJLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxVQUFVLENBQUE7QUFDL0UsQ0FBQztBQUVELFNBQVMsU0FBUyxDQUFDLENBQU07SUFDdkIsT0FBTyxDQUFDLElBQUksT0FBTyxDQUFDLEtBQUssUUFBUSxJQUFJLE9BQU8sQ0FBQyxDQUFDLElBQUksS0FBSyxVQUFVLENBQUE7QUFDbkUsQ0FBQztBQUVELFNBQVMsVUFBVSxDQUFDLEtBQVU7SUFDNUIsNkRBQTZEO0lBQzdELE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDdEIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogVGhpcyBtb2R1bGUgcHJvdmlkZXMgYSBjcmVhdGVUZXN0UnVudGltZSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYW4gb2JqZWN0IHdpdGggYSB0ZXN0IGZ1bmN0aW9uIHRoYXQgY2FuIGJlIHVzZWQgdG8gZGVmaW5lIHRlc3RzLlxuICovXG5cbmltcG9ydCB7IElFbmdpbmUsIFRyYW5zZm9ybSB9IGZyb20gJ0BkY2wvZWNzJ1xuaW1wb3J0IHsgYXNzZXJ0RXF1YWxzIH0gZnJvbSAnLi9hc3NlcnQnXG5pbXBvcnQgdHlwZSB7IFRlc3RpbmdNb2R1bGUsIFRlc3RGdW5jdGlvbiwgVGVzdEhlbHBlcnMgfSBmcm9tICcuL3R5cGVzJ1xuXG4vLyBUaGlzIGZ1bmN0aW9uIGNyZWF0ZXMgYSB0ZXN0IHJ1bnRpbWUgdGhhdCBjYW4gYmUgdXNlZCB0byBkZWZpbmUgYW5kIHJ1biB0ZXN0cy5cbi8vIEl0IHRha2VzIGEgYFRlc3RpbmdNb2R1bGVgIGluc3RhbmNlIChsb2FkZWQgZnJvbSByZXF1aXJlKCd+c3lzdGVtL1Rlc3RpbmcnKSkgYW5kIGFuIGBJRW5naW5lYCBpbnN0YW5jZSAoZnJvbSBEZWNlbnRyYWxhbmQncyBTREspLlxuLy8gSXQgcmV0dXJucyBhbiBvYmplY3Qgd2l0aCBhIGB0ZXN0YCBmdW5jdGlvbiB0aGF0IGNhbiBiZSB1c2VkIHRvIGRlZmluZSB0ZXN0cy5cbi8qIEBfX1BVUkVfXyAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVRlc3RSdW50aW1lKHRlc3RpbmdNb2R1bGU6IFRlc3RpbmdNb2R1bGUsIGVuZ2luZTogSUVuZ2luZSkge1xuICB0eXBlIFRlc3RQbGFuRW50cnkgPSB7IG5hbWU6IHN0cmluZzsgZm46IFRlc3RGdW5jdGlvbiB9XG4gIHR5cGUgUnVubmVyRW52aXJvbm1lbnQgPSB7XG4gICAgcmVzb2x2ZTogKCkgPT4gdm9pZFxuICAgIHJlamVjdDogKGVycm9yOiBhbnkpID0+IHZvaWRcbiAgICBoZWxwZXJzOiBUZXN0SGVscGVyc1xuICAgIGdlbmVyYXRvcjogR2VuZXJhdG9yXG4gIH1cblxuICAvLyB0aGlzIGZsYWcgZW5zdXJlcyBubyB0ZXN0cyBhcmUgYWRkZWQgYXN5bmNocm9ub3VzbHlcbiAgbGV0IHJ1bnRpbWVGcm96ZW4gPSBmYWxzZVxuXG4gIGxldCBjdXJyZW50RnJhbWVDb3VudGVyID0gMFxuICBsZXQgY3VycmVudEZyYW1lVGltZSA9IDBcblxuICAvLyBhcnJheSB0byBob2xkIHRoZSBzY2hlZHVsZWQgdGVzdHNcbiAgY29uc3Qgc2NoZWR1bGVkVGVzdHM6IFRlc3RQbGFuRW50cnlbXSA9IFtdXG5cbiAgLy8gYW4gYXJyYXkgb2YgcHJvbWlzZXMgdGhhdCBhcmUgcmVzb2x2ZWQgb24gdGhlIG5leHQgZnJhbWUgKGFmdGVyIHRoZSBjdXJyZW50IGZyYW1lIGlzIGZpbmlzaGVkKVxuICBjb25zdCBuZXh0VGlja0Z1dHVyZTogQXJyYXk8KGR0OiBudW1iZXIpID0+IHZvaWQ+ID0gW11cblxuICAvLyB0aGlzIGZ1bmN0aW9uIHJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb24gdGhlIG5leHQgZnJhbWVcbiAgYXN5bmMgZnVuY3Rpb24gbmV4dFRpY2soKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPG51bWJlcj4oKHJlc29sdmUpID0+IHtcbiAgICAgIG5leHRUaWNrRnV0dXJlLnB1c2gocmVzb2x2ZSlcbiAgICB9KVxuICB9XG5cbiAgLy8gYWRkIGEgc3lzdGVtIHRvIHRoZSBlbmdpbmUgdGhhdCByZXNvbHZlcyBhbGwgcHJvbWlzZXMgaW4gdGhlIGBuZXh0VGlja0Z1dHVyZWAgYXJyYXlcbiAgZW5naW5lLmFkZFN5c3RlbShmdW5jdGlvbiBUZXN0aW5nRnJhbWV3b3JrQ29yb3V0aW5lUnVubmVyKGR0KSB7XG4gICAgY3VycmVudEZyYW1lQ291bnRlcisrXG4gICAgY3VycmVudEZyYW1lVGltZSArPSBkdFxuICAgIC8vIHJlc29sdmUgYWxsIG5leHRUaWNrIGZ1dHVyZXMuXG4gICAgbmV4dFRpY2tGdXR1cmUuc3BsaWNlKDAsIG5leHRUaWNrRnV0dXJlLmxlbmd0aCkuZm9yRWFjaCgoXykgPT4gXyhkdCkpXG4gIH0pXG5cbiAgLy8gdGhpcyBmdW5jdGlvbiBzY2hlZHVsZXMgYSB2YWx1ZSB0byBiZSBwcm9jZXNzZWQgb24gdGhlIG5leHQgZnJhbWUsIHRoZSB0ZXN0IHJ1bm5lciB3aWxsXG4gIC8vIGNvbnRpbnVlIHRvIHJ1biB1bnRpbCBpdCByZWFjaGVzIGEgeWllbGQgcG9pbnRcbiAgZnVuY3Rpb24gc2NoZWR1bGVWYWx1ZSh2YWx1ZTogYW55LCBlbnY6IFJ1bm5lckVudmlyb25tZW50KSB7XG4gICAgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIHZhbHVlLnRoZW4gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNvbnNvbGUubG9nKCfij7HvuI8geWllbGQgcHJvbWlzZScpXG4gICAgICAvLyBpZiB0aGUgdmFsdWUgaXMgYSBwcm9taXNlLCBzY2hlZHVsZSBpdCB0byBiZSBhd2FpdGVkIGFmdGVyIHRoZSBjdXJyZW50IGZyYW1lIGlzIGZpbmlzaGVkXG4gICAgICBuZXh0VGlja0Z1dHVyZS5wdXNoKGFzeW5jICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBzY2hlZHVsZVZhbHVlKGF3YWl0IHZhbHVlLCBlbnYpXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGVudi5yZWplY3QoZXJyKVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBjb25zb2xlLmxvZygn4o+x77iPIHlpZWxkIGZ1bmN0aW9uJylcbiAgICAgIC8vIGlmIHRoZSB2YWx1ZSBpcyBhIGZ1bmN0aW9uLCBzY2hlZHVsZSBpdCB0byBiZSBjYWxsZWQgb24gdGhlIG5leHQgZnJhbWVcbiAgICAgIG5leHRUaWNrRnV0dXJlLnB1c2goKCkgPT4ge1xuICAgICAgICBzY2hlZHVsZVZhbHVlKHZhbHVlKCksIGVudilcbiAgICAgIH0pXG4gICAgICByZXR1cm5cbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3VuZGVmaW5lZCcgfHwgdmFsdWUgPT09IG51bGwpIHtcbiAgICAgIGNvbnNvbGUubG9nKCfij7HvuI8geWllbGQnKVxuICAgICAgLy8gaWYgdGhlIHZhbHVlIGlzIHVuZGVmaW5lZCBvciBudWxsLCBjb250aW51ZSBwcm9jZXNzaW5nIHRoZSBnZW5lcmF0b3IgdGhlIG5leHQgZnJhbWVcbiAgICAgIG5leHRUaWNrRnV0dXJlLnB1c2goKCkgPT4ge1xuICAgICAgICBjb25zdW1lR2VuZXJhdG9yKGVudilcbiAgICAgIH0pXG4gICAgfSBlbHNlIHRocm93IG5ldyBFcnJvcihgVW5leHBlY3RlZCB2YWx1ZSBmcm9tIHRlc3QgZ2VuZXJhdG9yOiAke3ZhbHVlfWApXG4gIH1cblxuICAvLyB0aGlzIGZ1bmN0aW9uIHByb2Nlc3NlcyBhIGdlbmVyYXRvciBmdW5jdGlvbiBieSBzY2hlZHVsaW5nIGl0cyB2YWx1ZXMgdG8gYmUgcHJvY2Vzc2VkIG9uIHRoZSBuZXh0IGZyYW1lXG4gIGZ1bmN0aW9uIGNvbnN1bWVHZW5lcmF0b3IoZW52OiBSdW5uZXJFbnZpcm9ubWVudCkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXQgPSBlbnYuZ2VuZXJhdG9yLm5leHQoKVxuICAgICAgaWYgKCFyZXQuZG9uZSkge1xuICAgICAgICBzY2hlZHVsZVZhbHVlKHJldC52YWx1ZSwgZW52KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZW52LnJlc29sdmUoKVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgZW52LnJlamVjdChlcnIpXG4gICAgfVxuICB9XG5cbiAgLy8gdGhpcyBmdW5jdGlvbiBzY2hlZHVsZXMgYSB0ZXN0IHJ1biBvbiB0aGUgbmV4dCBmcmFtZVxuICBmdW5jdGlvbiBzY2hlZHVsZU5leHRSdW4oKSB7XG4gICAgaWYgKHNjaGVkdWxlZFRlc3RzLmxlbmd0aCkge1xuICAgICAgbmV4dFRpY2tGdXR1cmUucHVzaChydW5UZXN0cylcbiAgICB9XG4gIH1cblxuICAvLyB0aGlzIGZ1bmN0aW9uIHJ1bnMgdGhlIHNjaGVkdWxlZCB0ZXN0c1xuICBmdW5jdGlvbiBydW5UZXN0cygpIHtcbiAgICBpZiAoc2NoZWR1bGVkVGVzdHMubGVuZ3RoKSB7XG4gICAgICBjb25zdCBlbnRyeSA9IHNjaGVkdWxlZFRlc3RzLnNoaWZ0KCkhXG4gICAgICBjb25zdCBpbml0aWFsRnJhbWUgPSBjdXJyZW50RnJhbWVDb3VudGVyXG4gICAgICBjb25zdCBzdGFydFRpbWUgPSBjdXJyZW50RnJhbWVUaW1lXG5cbiAgICAgIGxldCByZXNvbHZlZCA9IGZhbHNlXG5cbiAgICAgIC8vIHRoaXMgZnVuY3Rpb24gc2hvdWxkIGJlIGNhbGxlZCBvbmx5IG9uY2UuIGl0IG1ha2VzIHRoZSBjdXJyZW50IHRlc3QgcGFzc1xuICAgICAgY29uc3QgcmVzb2x2ZSA9ICgpID0+IHtcbiAgICAgICAgaWYgKHJlc29sdmVkKSB0aHJvdyBuZXcgRXJyb3IoJ3Jlc29sdmVkIHR3aWNlJylcbiAgICAgICAgcmVzb2x2ZWQgPSB0cnVlXG5cbiAgICAgICAgY29uc29sZS5sb2coYPCfn6IgVGVzdCBwYXNzZWQgJHtlbnRyeS5uYW1lfWApXG5cbiAgICAgICAgdGVzdGluZ01vZHVsZVxuICAgICAgICAgIC5sb2dUZXN0UmVzdWx0KHtcbiAgICAgICAgICAgIG5hbWU6IGVudHJ5Lm5hbWUsXG4gICAgICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgICAgIHRvdGFsRnJhbWVzOiBjdXJyZW50RnJhbWVDb3VudGVyIC0gaW5pdGlhbEZyYW1lLFxuICAgICAgICAgICAgdG90YWxUaW1lOiBjdXJyZW50RnJhbWVUaW1lIC0gc3RhcnRUaW1lXG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZmluYWxseShzY2hlZHVsZU5leHRSdW4pXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJlamVjdCA9IChlcnI6IGFueSkgPT4ge1xuICAgICAgICBpZiAocmVzb2x2ZWQpIHRocm93IG5ldyBFcnJvcigncmVzb2x2ZWQgdHdpY2UnKVxuICAgICAgICByZXNvbHZlZCA9IHRydWVcblxuICAgICAgICBjb25zb2xlLmxvZyhg8J+UtCBUZXN0IGZhaWxlZCAke2VudHJ5Lm5hbWV9YClcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnIpXG5cbiAgICAgICAgdGVzdGluZ01vZHVsZVxuICAgICAgICAgIC5sb2dUZXN0UmVzdWx0KHtcbiAgICAgICAgICAgIG5hbWU6IGVudHJ5Lm5hbWUsXG4gICAgICAgICAgICBvazogZmFsc2UsXG4gICAgICAgICAgICBlcnJvcjogZXJyLnRvU3RyaW5nKCksXG4gICAgICAgICAgICBzdGFjazogZXJyICYmIHR5cGVvZiBlcnIgPT09ICdvYmplY3QnICYmIGVyci5zdGFjayxcbiAgICAgICAgICAgIHRvdGFsRnJhbWVzOiBjdXJyZW50RnJhbWVDb3VudGVyIC0gaW5pdGlhbEZyYW1lLFxuICAgICAgICAgICAgdG90YWxUaW1lOiBjdXJyZW50RnJhbWVUaW1lIC0gc3RhcnRUaW1lXG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZmluYWxseShzY2hlZHVsZU5leHRSdW4pXG4gICAgICB9XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGDwn6eqIFJ1bm5pbmcgdGVzdCAke2VudHJ5Lm5hbWV9YClcblxuICAgICAgICBjb25zdCB0ZXN0SGVscGVyczogVGVzdEhlbHBlcnMgPSB7XG4gICAgICAgICAgYXN5bmMgc2V0Q2FtZXJhVHJhbnNmb3JtKHRyYW5zZm9ybSkge1xuICAgICAgICAgICAgYXdhaXQgdGVzdGluZ01vZHVsZS5zZXRDYW1lcmFUcmFuc2Zvcm0odHJhbnNmb3JtKVxuICAgICAgICAgICAgYXdhaXQgbmV4dFRpY2soKVxuXG4gICAgICAgICAgICBjb25zdCBUcmFuc2Zvcm1Db21wb25lbnQgPSBlbmdpbmUuZ2V0Q29tcG9uZW50KFRyYW5zZm9ybS5jb21wb25lbnRJZCkgYXMgdHlwZW9mIFRyYW5zZm9ybVxuICAgICAgICAgICAgY29uc3QgYWN0dWFsVHJhbnNmb3JtID0gVHJhbnNmb3JtQ29tcG9uZW50LmdldChlbmdpbmUuQ2FtZXJhRW50aXR5KVxuXG4gICAgICAgICAgICBhc3NlcnRFcXVhbHMoYWN0dWFsVHJhbnNmb3JtLnBvc2l0aW9uLCB0cmFuc2Zvcm0ucG9zaXRpb24sIFwicG9zaXRpb25zIGRvbid0IG1hdGNoXCIpXG4gICAgICAgICAgICBhc3NlcnRFcXVhbHMoYWN0dWFsVHJhbnNmb3JtLnJvdGF0aW9uLCB0cmFuc2Zvcm0ucm90YXRpb24sIFwicm90YXRpb25zIGRvbid0IG1hdGNoXCIpXG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmV0dXJuVmFsdWUgPSBlbnRyeS5mbih0ZXN0SGVscGVycylcblxuICAgICAgICBpZiAocmV0dXJuVmFsdWUgJiYgdHlwZW9mIHJldHVyblZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgIGlmIChpc0dlbmVyYXRvcihyZXR1cm5WYWx1ZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGVudjogUnVubmVyRW52aXJvbm1lbnQgPSB7XG4gICAgICAgICAgICAgIGdlbmVyYXRvcjogcmV0dXJuVmFsdWUsXG4gICAgICAgICAgICAgIGhlbHBlcnM6IHRlc3RIZWxwZXJzLFxuICAgICAgICAgICAgICByZXNvbHZlLFxuICAgICAgICAgICAgICByZWplY3RcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN1bWVHZW5lcmF0b3IoZW52KVxuICAgICAgICAgIH0gZWxzZSBpZiAoaXNQcm9taXNlKHJldHVyblZhbHVlKSkge1xuICAgICAgICAgICAgcmV0dXJuVmFsdWUudGhlbihyZXNvbHZlKS5jYXRjaChyZWplY3QpXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biB0ZXN0IHJlc3VsdCB0eXBlOiAke3JldHVyblZhbHVlfWApXG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmUoKVxuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICByZWplY3QoZXJyKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8vIHNjaGVkdWxlIHRoZSB0ZXN0IHJ1bm5lciBzdGFydCBmb3IgdGhlIG5leHQgZnJhbWVcbiAgbmV4dFRpY2tGdXR1cmUucHVzaCgoKSA9PiB7XG4gICAgLy8gb25jZSB3ZSBydW4gdGhlIG5leHQgdGljaywgdGhlIHRlc3QgcnVudGltZSBiZWNvbWVzIGZyb3plbi4gdGhhdCBtZWFucyBubyBuZXdcbiAgICAvLyB0ZXN0IGRlZmluaXRpb25zIGFyZSBhY2NlcHRlZFxuICAgIHJ1bnRpbWVGcm96ZW4gPSB0cnVlXG5cbiAgICBpZiAoIXNjaGVkdWxlZFRlc3RzLmxlbmd0aCkgcmV0dXJuXG5cbiAgICAvLyBpbmZvcm0gdGhlIHRlc3QgcnVubmVyIGFib3V0IHRoZSBwbGFucyBmb3IgdGhpcyB0ZXN0IHJ1blxuICAgIHRlc3RpbmdNb2R1bGUucGxhbih7IHRlc3RzOiBzY2hlZHVsZWRUZXN0cyB9KS50aGVuKHNjaGVkdWxlTmV4dFJ1bikuY2F0Y2goZ2xvYmFsRmFpbClcbiAgfSlcblxuICAvLyB0aGlzIGlzIHRoZSBmdW5jdGlvbiB0aGF0IGlzIHVzZWQgdG8gcGxhbiBhIHRlc3QgZnVuY3Rpb25uXG4gIC8qIEBfX1BVUkVfXyAqL1xuICBmdW5jdGlvbiB0ZXN0KG5hbWU6IHN0cmluZywgZm46IFRlc3RGdW5jdGlvbikge1xuICAgIGlmIChydW50aW1lRnJvemVuKSB0aHJvdyBuZXcgRXJyb3IoXCJOZXcgdGVzdHMgY2FuJ3QgYmUgYWRkZWQgYXQgdGhpcyBzdGFnZS5cIilcblxuICAgIGlmIChzY2hlZHVsZWRUZXN0cy5zb21lKCgkKSA9PiAkLm5hbWUgPT09IG5hbWUpKSB0aHJvdyBuZXcgRXJyb3IoYFRlc3Qgd2l0aCBuYW1lICR7bmFtZX0gYWxyZWFkeSBleGlzdHNgKVxuXG4gICAgc2NoZWR1bGVkVGVzdHMucHVzaCh7IGZuLCBuYW1lIH0pXG4gIH1cblxuICByZXR1cm4ge1xuICAgIHRlc3RcbiAgfVxufVxuXG5mdW5jdGlvbiBpc0dlbmVyYXRvcih0OiBhbnkpOiB0IGlzIEdlbmVyYXRvciB7XG4gIHJldHVybiB0ICYmIHR5cGVvZiB0ID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgdFtTeW1ib2wuaXRlcmF0b3JdID09PSAnZnVuY3Rpb24nXG59XG5cbmZ1bmN0aW9uIGlzUHJvbWlzZSh0OiBhbnkpOiB0IGlzIFByb21pc2U8dW5rbm93bj4ge1xuICByZXR1cm4gdCAmJiB0eXBlb2YgdCA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIHQudGhlbiA9PT0gJ2Z1bmN0aW9uJ1xufVxuXG5mdW5jdGlvbiBnbG9iYWxGYWlsKGVycm9yOiBhbnkpIHtcbiAgLy8gZm9yIG5vdywgdGhlIGZhaWx1cmUgaXMgb25seSB3cml0aW5nIHRvIHRoZSBjb25zb2xlLmVycm9yLlxuICBjb25zb2xlLmVycm9yKGVycm9yKVxufVxuIl19