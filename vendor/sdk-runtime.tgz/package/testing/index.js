import { engine } from '@dcl/ecs';
import { createTestRuntime } from './runtime';
/**
 * In development builds, this function serves as test runner for automated test scenarios
 * if the runtime accepts the `~system/Testing` module
 * @public
 */
/* @__PURE__ */
export const test = DEBUG ? /* @__PURE__ */ createTestFunction() : /* @__PURE__ */ () => { };
function createTestFunction() {
    let testingModule;
    try {
        testingModule = /* @__PURE__ */ require('~system/Testing');
    }
    catch (err) {
        console.error(err);
        console.error(`🔴🚨‼️ WARNING: The test runner is not available. The test runner will be mocked. ‼️🚨🔴`);
        testingModule = {
            async logTestResult(data) {
                console.log(`🧪 mocked '~system/Testing'.logResult`, data);
                return {};
            },
            async plan(data) {
                console.log(`🧪 mocked '~system/Testing'.plan`, data);
                return {};
            },
            async setCameraTransform(transform) {
                console.log(`🧪 mocked '~system/Testing'.setCameraTransform`, transform);
                return {};
            }
        };
    }
    const runtime = createTestRuntime(testingModule, engine);
    return runtime.test;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvdGVzdGluZy9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sVUFBVSxDQUFBO0FBQ2pDLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLFdBQVcsQ0FBQTtBQUs3Qzs7OztHQUlHO0FBQ0gsZUFBZTtBQUNmLE1BQU0sQ0FBQyxNQUFNLElBQUksR0FBMkIsS0FBSyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEdBQUcsRUFBRSxHQUFFLENBQUMsQ0FBQTtBQUVuSCxTQUFTLGtCQUFrQjtJQUN6QixJQUFJLGFBQTRCLENBQUE7SUFDaEMsSUFBSTtRQUNGLGFBQWEsR0FBRyxlQUFlLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUE7S0FDM0Q7SUFBQyxPQUFPLEdBQUcsRUFBRTtRQUNaLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7UUFFbEIsT0FBTyxDQUFDLEtBQUssQ0FBQywwRkFBMEYsQ0FBQyxDQUFBO1FBRXpHLGFBQWEsR0FBRztZQUNkLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSTtnQkFDdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1Q0FBdUMsRUFBRSxJQUFJLENBQUMsQ0FBQTtnQkFDMUQsT0FBTyxFQUFFLENBQUE7WUFDWCxDQUFDO1lBQ0QsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJO2dCQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLEVBQUUsSUFBSSxDQUFDLENBQUE7Z0JBQ3JELE9BQU8sRUFBRSxDQUFBO1lBQ1gsQ0FBQztZQUNELEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTO2dCQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxFQUFFLFNBQVMsQ0FBQyxDQUFBO2dCQUN4RSxPQUFPLEVBQUUsQ0FBQTtZQUNYLENBQUM7U0FDRixDQUFBO0tBQ0Y7SUFFRCxNQUFNLE9BQU8sR0FBRyxpQkFBaUIsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUE7SUFDeEQsT0FBTyxPQUFPLENBQUMsSUFBSSxDQUFBO0FBQ3JCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBlbmdpbmUgfSBmcm9tICdAZGNsL2VjcydcbmltcG9ydCB7IGNyZWF0ZVRlc3RSdW50aW1lIH0gZnJvbSAnLi9ydW50aW1lJ1xuaW1wb3J0IHsgVGVzdERlZmluaXRpb25GdW5jdGlvbiwgVGVzdGluZ01vZHVsZSB9IGZyb20gJy4vdHlwZXMnXG5cbmRlY2xhcmUgbGV0IHJlcXVpcmU6IGFueVxuXG4vKipcbiAqIEluIGRldmVsb3BtZW50IGJ1aWxkcywgdGhpcyBmdW5jdGlvbiBzZXJ2ZXMgYXMgdGVzdCBydW5uZXIgZm9yIGF1dG9tYXRlZCB0ZXN0IHNjZW5hcmlvc1xuICogaWYgdGhlIHJ1bnRpbWUgYWNjZXB0cyB0aGUgYH5zeXN0ZW0vVGVzdGluZ2AgbW9kdWxlXG4gKiBAcHVibGljXG4gKi9cbi8qIEBfX1BVUkVfXyAqL1xuZXhwb3J0IGNvbnN0IHRlc3Q6IFRlc3REZWZpbml0aW9uRnVuY3Rpb24gPSBERUJVRyA/IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVUZXN0RnVuY3Rpb24oKSA6IC8qIEBfX1BVUkVfXyAqLyAoKSA9PiB7fVxuXG5mdW5jdGlvbiBjcmVhdGVUZXN0RnVuY3Rpb24oKSB7XG4gIGxldCB0ZXN0aW5nTW9kdWxlOiBUZXN0aW5nTW9kdWxlXG4gIHRyeSB7XG4gICAgdGVzdGluZ01vZHVsZSA9IC8qIEBfX1BVUkVfXyAqLyByZXF1aXJlKCd+c3lzdGVtL1Rlc3RpbmcnKVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKGVycilcblxuICAgIGNvbnNvbGUuZXJyb3IoYPCflLTwn5qo4oC877iPIFdBUk5JTkc6IFRoZSB0ZXN0IHJ1bm5lciBpcyBub3QgYXZhaWxhYmxlLiBUaGUgdGVzdCBydW5uZXIgd2lsbCBiZSBtb2NrZWQuIOKAvO+4j/Cfmqjwn5S0YClcblxuICAgIHRlc3RpbmdNb2R1bGUgPSB7XG4gICAgICBhc3luYyBsb2dUZXN0UmVzdWx0KGRhdGEpIHtcbiAgICAgICAgY29uc29sZS5sb2coYPCfp6ogbW9ja2VkICd+c3lzdGVtL1Rlc3RpbmcnLmxvZ1Jlc3VsdGAsIGRhdGEpXG4gICAgICAgIHJldHVybiB7fVxuICAgICAgfSxcbiAgICAgIGFzeW5jIHBsYW4oZGF0YSkge1xuICAgICAgICBjb25zb2xlLmxvZyhg8J+nqiBtb2NrZWQgJ35zeXN0ZW0vVGVzdGluZycucGxhbmAsIGRhdGEpXG4gICAgICAgIHJldHVybiB7fVxuICAgICAgfSxcbiAgICAgIGFzeW5jIHNldENhbWVyYVRyYW5zZm9ybSh0cmFuc2Zvcm0pIHtcbiAgICAgICAgY29uc29sZS5sb2coYPCfp6ogbW9ja2VkICd+c3lzdGVtL1Rlc3RpbmcnLnNldENhbWVyYVRyYW5zZm9ybWAsIHRyYW5zZm9ybSlcbiAgICAgICAgcmV0dXJuIHt9XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgY29uc3QgcnVudGltZSA9IGNyZWF0ZVRlc3RSdW50aW1lKHRlc3RpbmdNb2R1bGUsIGVuZ2luZSlcbiAgcmV0dXJuIHJ1bnRpbWUudGVzdFxufVxuIl19