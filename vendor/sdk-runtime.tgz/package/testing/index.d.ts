import { TestDefinitionFunction } from './types';
/**
 * In development builds, this function serves as test runner for automated test scenarios
 * if the runtime accepts the `~system/Testing` module
 * @public
 */
export declare const test: TestDefinitionFunction;
