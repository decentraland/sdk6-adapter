import type { Entity, LastWriteWinElementSetComponentDefinition } from '@dcl/ecs';
type Options = {
    strict: boolean;
    comp: typeof closeTo;
};
export declare function assertEquals(a: any, b: any, message?: string): void;
export declare function assert(a: any, message?: string): void;
export declare function assertComponentValue<T>(entity: Entity, component: LastWriteWinElementSetComponentDefinition<T>, value: T): void;
export declare function deepCloseTo(actual: any, expected: any, options?: Partial<Options>): boolean;
declare function closeTo(actual: any, expected: any, delta?: number): boolean;
export {};
