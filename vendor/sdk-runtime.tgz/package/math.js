/**
 * This module is exposed by the sdk via `@dcl/sdk/math`
 *

* @example
 * ```tsx
 * import { Color3, Vector3 } from '@dcl/sdk/math'
 * ```
 *
 * @module Math & Colors
 *
 */
export * from '@dcl/ecs-math';
export * from '@dcl/ecs-math/dist/Matrix';
export * from '@dcl/ecs-math/dist/Plane';
export { Vector3 } from '@dcl/ecs-math';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWF0aC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNyYy9tYXRoLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7OztHQVdHO0FBRUgsY0FBYyxlQUFlLENBQUE7QUFDN0IsY0FBYywyQkFBMkIsQ0FBQTtBQUN6QyxjQUFjLDBCQUEwQixDQUFBO0FBQ3hDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxlQUFlLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFRoaXMgbW9kdWxlIGlzIGV4cG9zZWQgYnkgdGhlIHNkayB2aWEgYEBkY2wvc2RrL21hdGhgXG4gKlxuXG4qIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGltcG9ydCB7IENvbG9yMywgVmVjdG9yMyB9IGZyb20gJ0BkY2wvc2RrL21hdGgnXG4gKiBgYGBcbiAqXG4gKiBAbW9kdWxlIE1hdGggJiBDb2xvcnNcbiAqXG4gKi9cblxuZXhwb3J0ICogZnJvbSAnQGRjbC9lY3MtbWF0aCdcbmV4cG9ydCAqIGZyb20gJ0BkY2wvZWNzLW1hdGgvZGlzdC9NYXRyaXgnXG5leHBvcnQgKiBmcm9tICdAZGNsL2Vjcy1tYXRoL2Rpc3QvUGxhbmUnXG5leHBvcnQgeyBWZWN0b3IzIH0gZnJvbSAnQGRjbC9lY3MtbWF0aCdcbiJdfQ==