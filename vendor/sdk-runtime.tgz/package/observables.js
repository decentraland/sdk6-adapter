import { Observable } from './internal/Observable';
import { AvatarBase, AvatarEmoteCommand, AvatarEquippedData, PlayerIdentityData, PointerEventsResult, RealmInfo, engine } from '@dcl/ecs';
import { subscribe } from '~system/EngineApi';
import players from './players';
/**
 * @internal
 * This function generates a callback that is passed to the Observable
 * constructor to subscribe to the events of the DecentralandInterface
 */
function createSubscriber(eventName) {
    return () => {
        if (eventName === 'comms') {
            subscribe({ eventId: eventName }).catch(console.error);
        }
        else {
            SDK7ComponentsObservable?.subscribe(eventName);
        }
    };
}
/**
 * These events are triggered after your character enters the scene.
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onEnterSceneObservable = new Observable(createSubscriber('onEnterScene'));
/** @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed. Use onEnterSceneObservable instead. */
export const onEnterScene = onEnterSceneObservable;
/**
 * These events are triggered after your character leaves the scene.
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onLeaveSceneObservable = new Observable(createSubscriber('onLeaveScene'));
/** @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed. Use onLeaveSceneObservable instead. */
export const onLeaveScene = onLeaveSceneObservable;
/**
 * This event is triggered after all the resources of the scene were loaded (models, textures, etc...)
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onSceneReadyObservable = new Observable(createSubscriber('sceneStart'));
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onPlayerExpressionObservable = new Observable(createSubscriber('playerExpression'));
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onVideoEvent = new Observable(createSubscriber('videoEvent'));
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onProfileChanged = new Observable(createSubscriber('profileChanged'));
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onPlayerConnectedObservable = new Observable(createSubscriber('playerConnected'));
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onPlayerDisconnectedObservable = new Observable(createSubscriber('playerDisconnected'));
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onRealmChangedObservable = new Observable(createSubscriber('onRealmChanged'));
/**
 * @public
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onPlayerClickedObservable = new Observable(createSubscriber('playerClicked'));
/**
 * @internal
 * @deprecated This function is an inheritance of ECS6, it's here temporary for the feature parity, please read the news and docs to know how handle when it's removed.
 */
export const onCommsMessage = new Observable(createSubscriber('comms'));
/**
 * @internal
 * @deprecated this is an OLD API.
 * This function uses the SDK6 sendBatch to poll events from the renderer
 */
export async function pollEvents(sendBatch) {
    const { events } = await sendBatch({ actions: [] });
    for (const e of events) {
        if (e.generic) {
            const data = JSON.parse(e.generic.eventData);
            switch (e.generic.eventId) {
                case 'comms': {
                    onCommsMessage.notifyObservers(data);
                    break;
                }
            }
        }
    }
}
const SDK7ComponentsObservable = processObservables();
function processObservables() {
    const subscriptions = new Set();
    function subscribe(eventName) {
        if (subscriptions.has(eventName))
            return;
        switch (eventName) {
            case 'playerClicked': {
                subscribePlayerClick();
                break;
            }
            case 'onEnterScene':
            case 'playerConnected': {
                subscribeEnterScene();
                break;
            }
            case 'onLeaveScene':
            case 'playerDisconnected': {
                subscribeLeaveScene();
                break;
            }
            case 'onRealmChanged': {
                subscribeRealmChange();
                break;
            }
            case 'playerExpression': {
                subscribePlayerExpression();
                break;
            }
            case 'profileChanged': {
                subscribeProfileChange();
                break;
            }
        }
        subscriptions.add(eventName);
    }
    /**
     * PLAYER ENTER/CONNECTED observable
     */
    function subscribeEnterScene() {
        players.onEnterScene((player) => {
            if (subscriptions.has('onEnterScene')) {
                onEnterSceneObservable.notifyObservers({ userId: player.userId });
            }
            if (subscriptions.has('playerConnected')) {
                onPlayerConnectedObservable.notifyObservers({ userId: player.userId });
            }
        });
    }
    /**
     * PLAYER LEAVE/DISCONNECTED observable
     */
    function subscribeLeaveScene() {
        players.onLeaveScene((userId) => {
            if (subscriptions.has('onLeaveScene')) {
                onLeaveSceneObservable.notifyObservers({ userId });
            }
            if (subscriptions.has('playerDisconnected')) {
                onPlayerDisconnectedObservable.notifyObservers({ userId });
            }
        });
    }
    /**
     * REALM CHANGE observable
     */
    function subscribeRealmChange() {
        RealmInfo.onChange(engine.RootEntity, (value) => {
            if (value) {
                onRealmChangedObservable.notifyObservers({
                    domain: value.baseUrl,
                    displayName: value.realmName,
                    room: value.room ?? '',
                    serverName: value.realmName
                });
            }
        });
    }
    /**
     * PLAYER/AVATAR CLICKED observable
     */
    function subscribePlayerClick() {
        const playerEntities = new Set();
        engine.addSystem(() => {
            for (const [entity] of engine.getEntitiesWith(PlayerIdentityData)) {
                if (playerEntities.has(entity))
                    continue;
                playerEntities.add(entity);
                PointerEventsResult.onChange(entity, (data) => {
                    if (data?.hit) {
                        onPlayerClickedObservable.notifyObservers({
                            userId: PlayerIdentityData.getOrNull(entity)?.address ?? '',
                            ray: {
                                direction: data.hit.direction,
                                distance: data.hit.length,
                                origin: data.hit.globalOrigin
                            }
                        });
                    }
                });
            }
        });
    }
    /**
     * Player expression observable
     */
    function subscribePlayerExpression() {
        AvatarEmoteCommand.onChange(engine.PlayerEntity, (value) => {
            onPlayerExpressionObservable.notifyObservers({ expressionId: value?.emoteUrn ?? '' });
        });
    }
    /**
     * PROFILE CHANGE observable
     */
    function subscribeProfileChange() {
        AvatarBase.onChange(engine.PlayerEntity, () => {
            if (!profileAddress)
                return;
            onProfileChanged.notifyObservers({ ethAddress: profileAddress, version: 0 });
        });
        AvatarEquippedData.onChange(engine.PlayerEntity, () => {
            if (!profileAddress)
                return;
            onProfileChanged.notifyObservers({ ethAddress: profileAddress, version: 0 });
        });
    }
    // Flag to call once the scene is initalized.
    let sceneReady = false;
    let profileAddress;
    function observableSystem() {
        if (sceneReady && profileAddress) {
            return engine.removeSystem(observableSystem);
        }
        if (!sceneReady) {
            sceneReady = true;
            onSceneReadyObservable.notifyObservers({});
        }
        if (profileAddress)
            return;
        profileAddress = PlayerIdentityData.getOrNull(engine.PlayerEntity)?.address;
    }
    engine.addSystem(observableSystem);
    return { subscribe };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib2JzZXJ2YWJsZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzcmMvb2JzZXJ2YWJsZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLHVCQUF1QixDQUFBO0FBQ2xELE9BQU8sRUFDTCxVQUFVLEVBQ1Ysa0JBQWtCLEVBQ2xCLGtCQUFrQixFQUVsQixrQkFBa0IsRUFDbEIsbUJBQW1CLEVBQ25CLFNBQVMsRUFFVCxNQUFNLEVBQ1AsTUFBTSxVQUFVLENBQUE7QUFDakIsT0FBTyxFQUF1QyxTQUFTLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQTtBQUNsRixPQUFPLE9BQU8sTUFBTSxXQUFXLENBQUE7QUEwRi9COzs7O0dBSUc7QUFDSCxTQUFTLGdCQUFnQixDQUFDLFNBQXdCO0lBQ2hELE9BQU8sR0FBRyxFQUFFO1FBQ1YsSUFBSSxTQUFTLEtBQUssT0FBTyxFQUFFO1lBQ3pCLFNBQVMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUE7U0FDdkQ7YUFBTTtZQUNMLHdCQUF3QixFQUFFLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQTtTQUMvQztJQUNILENBQUMsQ0FBQTtBQUNILENBQUM7QUFFRDs7OztHQUlHO0FBQ0gsTUFBTSxDQUFDLE1BQU0sc0JBQXNCLEdBQUcsSUFBSSxVQUFVLENBQTBCLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUE7QUFDL0c7OzhNQUU4TTtBQUM5TSxNQUFNLENBQUMsTUFBTSxZQUFZLEdBQUcsc0JBQXNCLENBQUE7QUFFbEQ7Ozs7R0FJRztBQUNILE1BQU0sQ0FBQyxNQUFNLHNCQUFzQixHQUFHLElBQUksVUFBVSxDQUEwQixnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFBO0FBRS9HOzs4TUFFOE07QUFDOU0sTUFBTSxDQUFDLE1BQU0sWUFBWSxHQUFHLHNCQUFzQixDQUFBO0FBRWxEOzs7O0dBSUc7QUFDSCxNQUFNLENBQUMsTUFBTSxzQkFBc0IsR0FBRyxJQUFJLFVBQVUsQ0FBd0IsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQTtBQUUzRzs7O0dBR0c7QUFDSCxNQUFNLENBQUMsTUFBTSw0QkFBNEIsR0FBRyxJQUFJLFVBQVUsQ0FDeEQsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsQ0FDckMsQ0FBQTtBQUVEOzs7R0FHRztBQUNILE1BQU0sQ0FBQyxNQUFNLFlBQVksR0FBRyxJQUFJLFVBQVUsQ0FBd0IsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQTtBQUVqRzs7O0dBR0c7QUFDSCxNQUFNLENBQUMsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLFVBQVUsQ0FBNEIsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFBO0FBRTdHOzs7R0FHRztBQUNILE1BQU0sQ0FBQyxNQUFNLDJCQUEyQixHQUFHLElBQUksVUFBVSxDQUN2RCxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FBQyxDQUNwQyxDQUFBO0FBRUQ7OztHQUdHO0FBQ0gsTUFBTSxDQUFDLE1BQU0sOEJBQThCLEdBQUcsSUFBSSxVQUFVLENBQzFELGdCQUFnQixDQUFDLG9CQUFvQixDQUFDLENBQ3ZDLENBQUE7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLENBQUMsTUFBTSx3QkFBd0IsR0FBRyxJQUFJLFVBQVUsQ0FBNEIsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFBO0FBRXJIOzs7R0FHRztBQUNILE1BQU0sQ0FBQyxNQUFNLHlCQUF5QixHQUFHLElBQUksVUFBVSxDQUEyQixnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFBO0FBRXBIOzs7R0FHRztBQUNILE1BQU0sQ0FBQyxNQUFNLGNBQWMsR0FBRyxJQUFJLFVBQVUsQ0FBbUIsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtBQUV6Rjs7OztHQUlHO0FBQ0gsTUFBTSxDQUFDLEtBQUssVUFBVSxVQUFVLENBQUMsU0FBaUU7SUFDaEcsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sU0FBUyxDQUFDLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUE7SUFDbkQsS0FBSyxNQUFNLENBQUMsSUFBSSxNQUFNLEVBQUU7UUFDdEIsSUFBSSxDQUFDLENBQUMsT0FBTyxFQUFFO1lBQ2IsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFBO1lBQzVDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUU7Z0JBQ3pCLEtBQUssT0FBTyxDQUFDLENBQUM7b0JBQ1osY0FBYyxDQUFDLGVBQWUsQ0FBQyxJQUF3QixDQUFDLENBQUE7b0JBQ3hELE1BQUs7aUJBQ047YUFDRjtTQUNGO0tBQ0Y7QUFDSCxDQUFDO0FBRUQsTUFBTSx3QkFBd0IsR0FBRyxrQkFBa0IsRUFBRSxDQUFBO0FBQ3JELFNBQVMsa0JBQWtCO0lBQ3pCLE1BQU0sYUFBYSxHQUFHLElBQUksR0FBRyxFQUFpQixDQUFBO0lBRTlDLFNBQVMsU0FBUyxDQUFDLFNBQXdCO1FBQ3pDLElBQUksYUFBYSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7WUFBRSxPQUFNO1FBQ3hDLFFBQVEsU0FBUyxFQUFFO1lBQ2pCLEtBQUssZUFBZSxDQUFDLENBQUM7Z0JBQ3BCLG9CQUFvQixFQUFFLENBQUE7Z0JBQ3RCLE1BQUs7YUFDTjtZQUNELEtBQUssY0FBYyxDQUFDO1lBQ3BCLEtBQUssaUJBQWlCLENBQUMsQ0FBQztnQkFDdEIsbUJBQW1CLEVBQUUsQ0FBQTtnQkFDckIsTUFBSzthQUNOO1lBQ0QsS0FBSyxjQUFjLENBQUM7WUFDcEIsS0FBSyxvQkFBb0IsQ0FBQyxDQUFDO2dCQUN6QixtQkFBbUIsRUFBRSxDQUFBO2dCQUNyQixNQUFLO2FBQ047WUFDRCxLQUFLLGdCQUFnQixDQUFDLENBQUM7Z0JBQ3JCLG9CQUFvQixFQUFFLENBQUE7Z0JBQ3RCLE1BQUs7YUFDTjtZQUNELEtBQUssa0JBQWtCLENBQUMsQ0FBQztnQkFDdkIseUJBQXlCLEVBQUUsQ0FBQTtnQkFDM0IsTUFBSzthQUNOO1lBQ0QsS0FBSyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUNyQixzQkFBc0IsRUFBRSxDQUFBO2dCQUN4QixNQUFLO2FBQ047U0FDRjtRQUNELGFBQWEsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUE7SUFDOUIsQ0FBQztJQUNEOztPQUVHO0lBQ0gsU0FBUyxtQkFBbUI7UUFDMUIsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFO1lBQzlCLElBQUksYUFBYSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDckMsc0JBQXNCLENBQUMsZUFBZSxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFBO2FBQ2xFO1lBRUQsSUFBSSxhQUFhLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0JBQ3hDLDJCQUEyQixDQUFDLGVBQWUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQTthQUN2RTtRQUNILENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUNEOztPQUVHO0lBQ0gsU0FBUyxtQkFBbUI7UUFDMUIsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFO1lBQzlCLElBQUksYUFBYSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRTtnQkFDckMsc0JBQXNCLENBQUMsZUFBZSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQTthQUNuRDtZQUVELElBQUksYUFBYSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFO2dCQUMzQyw4QkFBOEIsQ0FBQyxlQUFlLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFBO2FBQzNEO1FBQ0gsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBQ0Q7O09BRUc7SUFDSCxTQUFTLG9CQUFvQjtRQUMzQixTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUM5QyxJQUFJLEtBQUssRUFBRTtnQkFDVCx3QkFBd0IsQ0FBQyxlQUFlLENBQUM7b0JBQ3ZDLE1BQU0sRUFBRSxLQUFLLENBQUMsT0FBTztvQkFDckIsV0FBVyxFQUFFLEtBQUssQ0FBQyxTQUFTO29CQUM1QixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksSUFBSSxFQUFFO29CQUN0QixVQUFVLEVBQUUsS0FBSyxDQUFDLFNBQVM7aUJBQzVCLENBQUMsQ0FBQTthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBQ0Q7O09BRUc7SUFDSCxTQUFTLG9CQUFvQjtRQUMzQixNQUFNLGNBQWMsR0FBRyxJQUFJLEdBQUcsRUFBVSxDQUFBO1FBQ3hDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ3BCLEtBQUssTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUMsRUFBRTtnQkFDakUsSUFBSSxjQUFjLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztvQkFBRSxTQUFRO2dCQUN4QyxjQUFjLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFBO2dCQUUxQixtQkFBbUIsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUU7b0JBQzVDLElBQUksSUFBSSxFQUFFLEdBQUcsRUFBRTt3QkFDYix5QkFBeUIsQ0FBQyxlQUFlLENBQUM7NEJBQ3hDLE1BQU0sRUFBRSxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsT0FBTyxJQUFJLEVBQUU7NEJBQzNELEdBQUcsRUFBRTtnQ0FDSCxTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFVO2dDQUM5QixRQUFRLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNO2dDQUN6QixNQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFhOzZCQUMvQjt5QkFDRixDQUFDLENBQUE7cUJBQ0g7Z0JBQ0gsQ0FBQyxDQUFDLENBQUE7YUFDSDtRQUNILENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsU0FBUyx5QkFBeUI7UUFDaEMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUN6RCw0QkFBNEIsQ0FBQyxlQUFlLENBQUMsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLFFBQVEsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFBO1FBQ3ZGLENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsU0FBUyxzQkFBc0I7UUFDN0IsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLEdBQUcsRUFBRTtZQUM1QyxJQUFJLENBQUMsY0FBYztnQkFBRSxPQUFNO1lBQzNCLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxFQUFFLFVBQVUsRUFBRSxjQUFjLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUE7UUFDOUUsQ0FBQyxDQUFDLENBQUE7UUFFRixrQkFBa0IsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxHQUFHLEVBQUU7WUFDcEQsSUFBSSxDQUFDLGNBQWM7Z0JBQUUsT0FBTTtZQUMzQixnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsRUFBRSxVQUFVLEVBQUUsY0FBYyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQzlFLENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELDZDQUE2QztJQUM3QyxJQUFJLFVBQVUsR0FBRyxLQUFLLENBQUE7SUFDdEIsSUFBSSxjQUFrQyxDQUFBO0lBRXRDLFNBQVMsZ0JBQWdCO1FBQ3ZCLElBQUksVUFBVSxJQUFJLGNBQWMsRUFBRTtZQUNoQyxPQUFPLE1BQU0sQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtTQUM3QztRQUNELElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDZixVQUFVLEdBQUcsSUFBSSxDQUFBO1lBQ2pCLHNCQUFzQixDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQTtTQUMzQztRQUNELElBQUksY0FBYztZQUFFLE9BQU07UUFDMUIsY0FBYyxHQUFHLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsT0FBTyxDQUFBO0lBQzdFLENBQUM7SUFFRCxNQUFNLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLENBQUE7SUFFbEMsT0FBTyxFQUFFLFNBQVMsRUFBRSxDQUFBO0FBQ3RCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi9pbnRlcm5hbC9PYnNlcnZhYmxlJ1xuaW1wb3J0IHtcbiAgQXZhdGFyQmFzZSxcbiAgQXZhdGFyRW1vdGVDb21tYW5kLFxuICBBdmF0YXJFcXVpcHBlZERhdGEsXG4gIEVudGl0eSxcbiAgUGxheWVySWRlbnRpdHlEYXRhLFxuICBQb2ludGVyRXZlbnRzUmVzdWx0LFxuICBSZWFsbUluZm8sXG4gIFZlY3RvcjNUeXBlLFxuICBlbmdpbmVcbn0gZnJvbSAnQGRjbC9lY3MnXG5pbXBvcnQgeyBNYW55RW50aXR5QWN0aW9uLCBTZW5kQmF0Y2hSZXNwb25zZSwgc3Vic2NyaWJlIH0gZnJvbSAnfnN5c3RlbS9FbmdpbmVBcGknXG5pbXBvcnQgcGxheWVycyBmcm9tICcuL3BsYXllcnMnXG5cbi8vLyAtLS0gRVZFTlRTIC0tLVxuXG4vKiogQHB1YmxpYyAqL1xuZXhwb3J0IHR5cGUgSUV2ZW50TmFtZXMgPSBrZXlvZiBJRXZlbnRzXG5cbi8qKlxuICogQHB1YmxpY1xuICogTm90ZTogRG9uJ3QgdXNlIGBvbmAgcHJlZml4IGZvciBJRXZlbnRzIHRvIGF2b2lkIHJlZHVuZGFuY3kgd2l0aCBgZXZlbnQub24oXCJvbkV2ZW50TmFtZVwiKWAgc3ludGF4LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElFdmVudHMge1xuICBwbGF5ZXJFeHByZXNzaW9uOiB7XG4gICAgZXhwcmVzc2lvbklkOiBzdHJpbmdcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGV2ZW50IGdldHMgdHJpZ2dlcmVkIHdoZW4gdGhlIHVzZXIgZW50ZXJzIHRoZSBzY2VuZVxuICAgKi9cbiAgb25FbnRlclNjZW5lOiB7XG4gICAgdXNlcklkOiBzdHJpbmdcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGV2ZW50IGdldHMgdHJpZ2dlcmVkIHdoZW4gdGhlIHVzZXIgbGVhdmVzIHRoZSBzY2VuZVxuICAgKi9cbiAgb25MZWF2ZVNjZW5lOiB7XG4gICAgdXNlcklkOiBzdHJpbmdcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGV2ZW50IGdldHMgdHJpZ2dlcmVkIGFmdGVyIHJlY2VpdmluZyBhIGNvbW1zIG1lc3NhZ2UuXG4gICAqL1xuICBjb21tczoge1xuICAgIHNlbmRlcjogc3RyaW5nXG4gICAgbWVzc2FnZTogc3RyaW5nXG4gIH1cblxuICAvKipcbiAgICogVGhpcyBpcyB0cmlnZ2VyZWQgb25jZSB0aGUgc2NlbmUgc2hvdWxkIHN0YXJ0LlxuICAgKi9cbiAgc2NlbmVTdGFydDogdW5rbm93blxuXG4gIC8qKiBUaGlzIGlzIHRyaWdnZXJlZCBhdCBsZWFzdCBmb3IgZWFjaCB2aWRlb1N0YXR1cyBjaGFuZ2UgKi9cbiAgdmlkZW9FdmVudDoge1xuICAgIGNvbXBvbmVudElkOiBzdHJpbmdcbiAgICB2aWRlb0NsaXBJZDogc3RyaW5nXG4gICAgLyoqIFN0YXR1cywgY2FuIGJlIE5PTkUgPSAwLCBFUlJPUiA9IDEsIExPQURJTkcgPSAyLCBSRUFEWSA9IDMsIFBMQVlJTkcgPSA0LEJVRkZFUklORyA9IDUgKi9cbiAgICB2aWRlb1N0YXR1czogbnVtYmVyXG4gICAgLyoqIEN1cnJlbnQgb2Zmc2V0IHBvc2l0aW9uIGluIHNlY29uZHMgKi9cbiAgICBjdXJyZW50T2Zmc2V0OiBudW1iZXJcbiAgICAvKiogVmlkZW8gbGVuZ3RoIGluIHNlY29uZHMuIENhbiBiZSAtMSAqL1xuICAgIHRvdGFsVmlkZW9MZW5ndGg6IG51bWJlclxuICB9XG5cbiAgLyoqIFRoaXMgaXMgdHJpZ2dlciBldmVyeXRpbWUgYSBwcm9maWxlIGlzIGNoYW5nZWQgKi9cbiAgcHJvZmlsZUNoYW5nZWQ6IHtcbiAgICBldGhBZGRyZXNzOiBzdHJpbmdcbiAgICB2ZXJzaW9uOiBudW1iZXJcbiAgfVxuXG4gIC8qKiBUcmlnZ2VyZWQgd2hlbiBwZWVyJ3MgYXZhdGFyIGlzIGNvbm5lY3RlZCBhbmQgdmlzaWJsZSAqL1xuICBwbGF5ZXJDb25uZWN0ZWQ6IHtcbiAgICB1c2VySWQ6IHN0cmluZ1xuICB9XG5cbiAgLyoqIFRyaWdnZXJlZCB3aGVuIHBlZXIgZGlzY29ubmVjdCBhbmQvb3IgaXQgYXZhdGFyIGlzIHNldCBpbnZpc2libGUgYnkgY29tbXMgKi9cbiAgcGxheWVyRGlzY29ubmVjdGVkOiB7XG4gICAgdXNlcklkOiBzdHJpbmdcbiAgfVxuXG4gIC8qKiBUcmlnZ2VyZWQgd2hlbiBjdXJyZW50IHJlYWxtIG9yIGlzbGFuZCBjaGFuZ2VzICovXG4gIG9uUmVhbG1DaGFuZ2VkOiB7XG4gICAgZG9tYWluOiBzdHJpbmdcbiAgICByb29tOiBzdHJpbmdcbiAgICBzZXJ2ZXJOYW1lOiBzdHJpbmdcbiAgICBkaXNwbGF5TmFtZTogc3RyaW5nXG4gIH1cblxuICAvKiogVHJpZ2dlcmVkIHdoZW4gb3RoZXIgcGxheWVyJ3MgYXZhdGFyIGlzIGNsaWNrZWQgKi9cbiAgcGxheWVyQ2xpY2tlZDoge1xuICAgIHVzZXJJZDogc3RyaW5nXG4gICAgcmF5OiB7XG4gICAgICBvcmlnaW46IFZlY3RvcjNUeXBlXG4gICAgICBkaXJlY3Rpb246IFZlY3RvcjNUeXBlXG4gICAgICBkaXN0YW5jZTogbnVtYmVyXG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogQGludGVybmFsXG4gKiBUaGlzIGZ1bmN0aW9uIGdlbmVyYXRlcyBhIGNhbGxiYWNrIHRoYXQgaXMgcGFzc2VkIHRvIHRoZSBPYnNlcnZhYmxlXG4gKiBjb25zdHJ1Y3RvciB0byBzdWJzY3JpYmUgdG8gdGhlIGV2ZW50cyBvZiB0aGUgRGVjZW50cmFsYW5kSW50ZXJmYWNlXG4gKi9cbmZ1bmN0aW9uIGNyZWF0ZVN1YnNjcmliZXIoZXZlbnROYW1lOiBrZXlvZiBJRXZlbnRzKSB7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgaWYgKGV2ZW50TmFtZSA9PT0gJ2NvbW1zJykge1xuICAgICAgc3Vic2NyaWJlKHsgZXZlbnRJZDogZXZlbnROYW1lIH0pLmNhdGNoKGNvbnNvbGUuZXJyb3IpXG4gICAgfSBlbHNlIHtcbiAgICAgIFNESzdDb21wb25lbnRzT2JzZXJ2YWJsZT8uc3Vic2NyaWJlKGV2ZW50TmFtZSlcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBUaGVzZSBldmVudHMgYXJlIHRyaWdnZXJlZCBhZnRlciB5b3VyIGNoYXJhY3RlciBlbnRlcnMgdGhlIHNjZW5lLlxuICogQHB1YmxpY1xuICogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiBpcyBhbiBpbmhlcml0YW5jZSBvZiBFQ1M2LCBpdCdzIGhlcmUgdGVtcG9yYXJ5IGZvciB0aGUgZmVhdHVyZSBwYXJpdHksIHBsZWFzZSByZWFkIHRoZSBuZXdzIGFuZCBkb2NzIHRvIGtub3cgaG93IGhhbmRsZSB3aGVuIGl0J3MgcmVtb3ZlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IG9uRW50ZXJTY2VuZU9ic2VydmFibGUgPSBuZXcgT2JzZXJ2YWJsZTxJRXZlbnRzWydvbkVudGVyU2NlbmUnXT4oY3JlYXRlU3Vic2NyaWJlcignb25FbnRlclNjZW5lJykpXG4vKiogQHB1YmxpY1xuICogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiBpcyBhbiBpbmhlcml0YW5jZSBvZiBFQ1M2LCBpdCdzIGhlcmUgdGVtcG9yYXJ5IGZvciB0aGUgZmVhdHVyZSBwYXJpdHksIHBsZWFzZSByZWFkIHRoZSBuZXdzIGFuZCBkb2NzIHRvIGtub3cgaG93IGhhbmRsZSB3aGVuIGl0J3MgcmVtb3ZlZC5cbiAqIEBkZXByZWNhdGVkIFRoaXMgZnVuY3Rpb24gaXMgYW4gaW5oZXJpdGFuY2Ugb2YgRUNTNiwgaXQncyBoZXJlIHRlbXBvcmFyeSBmb3IgdGhlIGZlYXR1cmUgcGFyaXR5LCBwbGVhc2UgcmVhZCB0aGUgbmV3cyBhbmQgZG9jcyB0byBrbm93IGhvdyBoYW5kbGUgd2hlbiBpdCdzIHJlbW92ZWQuIFVzZSBvbkVudGVyU2NlbmVPYnNlcnZhYmxlIGluc3RlYWQuICovXG5leHBvcnQgY29uc3Qgb25FbnRlclNjZW5lID0gb25FbnRlclNjZW5lT2JzZXJ2YWJsZVxuXG4vKipcbiAqIFRoZXNlIGV2ZW50cyBhcmUgdHJpZ2dlcmVkIGFmdGVyIHlvdXIgY2hhcmFjdGVyIGxlYXZlcyB0aGUgc2NlbmUuXG4gKiBAcHVibGljXG4gKiBAZGVwcmVjYXRlZCBUaGlzIGZ1bmN0aW9uIGlzIGFuIGluaGVyaXRhbmNlIG9mIEVDUzYsIGl0J3MgaGVyZSB0ZW1wb3JhcnkgZm9yIHRoZSBmZWF0dXJlIHBhcml0eSwgcGxlYXNlIHJlYWQgdGhlIG5ld3MgYW5kIGRvY3MgdG8ga25vdyBob3cgaGFuZGxlIHdoZW4gaXQncyByZW1vdmVkLlxuICovXG5leHBvcnQgY29uc3Qgb25MZWF2ZVNjZW5lT2JzZXJ2YWJsZSA9IG5ldyBPYnNlcnZhYmxlPElFdmVudHNbJ29uTGVhdmVTY2VuZSddPihjcmVhdGVTdWJzY3JpYmVyKCdvbkxlYXZlU2NlbmUnKSlcblxuLyoqIEBwdWJsaWNcbiAqIEBkZXByZWNhdGVkIFRoaXMgZnVuY3Rpb24gaXMgYW4gaW5oZXJpdGFuY2Ugb2YgRUNTNiwgaXQncyBoZXJlIHRlbXBvcmFyeSBmb3IgdGhlIGZlYXR1cmUgcGFyaXR5LCBwbGVhc2UgcmVhZCB0aGUgbmV3cyBhbmQgZG9jcyB0byBrbm93IGhvdyBoYW5kbGUgd2hlbiBpdCdzIHJlbW92ZWQuXG4gKiBAZGVwcmVjYXRlZCBUaGlzIGZ1bmN0aW9uIGlzIGFuIGluaGVyaXRhbmNlIG9mIEVDUzYsIGl0J3MgaGVyZSB0ZW1wb3JhcnkgZm9yIHRoZSBmZWF0dXJlIHBhcml0eSwgcGxlYXNlIHJlYWQgdGhlIG5ld3MgYW5kIGRvY3MgdG8ga25vdyBob3cgaGFuZGxlIHdoZW4gaXQncyByZW1vdmVkLiBVc2Ugb25MZWF2ZVNjZW5lT2JzZXJ2YWJsZSBpbnN0ZWFkLiAqL1xuZXhwb3J0IGNvbnN0IG9uTGVhdmVTY2VuZSA9IG9uTGVhdmVTY2VuZU9ic2VydmFibGVcblxuLyoqXG4gKiBUaGlzIGV2ZW50IGlzIHRyaWdnZXJlZCBhZnRlciBhbGwgdGhlIHJlc291cmNlcyBvZiB0aGUgc2NlbmUgd2VyZSBsb2FkZWQgKG1vZGVscywgdGV4dHVyZXMsIGV0Yy4uLilcbiAqIEBwdWJsaWNcbiAqIEBkZXByZWNhdGVkIFRoaXMgZnVuY3Rpb24gaXMgYW4gaW5oZXJpdGFuY2Ugb2YgRUNTNiwgaXQncyBoZXJlIHRlbXBvcmFyeSBmb3IgdGhlIGZlYXR1cmUgcGFyaXR5LCBwbGVhc2UgcmVhZCB0aGUgbmV3cyBhbmQgZG9jcyB0byBrbm93IGhvdyBoYW5kbGUgd2hlbiBpdCdzIHJlbW92ZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBvblNjZW5lUmVhZHlPYnNlcnZhYmxlID0gbmV3IE9ic2VydmFibGU8SUV2ZW50c1snc2NlbmVTdGFydCddPihjcmVhdGVTdWJzY3JpYmVyKCdzY2VuZVN0YXJ0JykpXG5cbi8qKlxuICogQHB1YmxpY1xuICogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiBpcyBhbiBpbmhlcml0YW5jZSBvZiBFQ1M2LCBpdCdzIGhlcmUgdGVtcG9yYXJ5IGZvciB0aGUgZmVhdHVyZSBwYXJpdHksIHBsZWFzZSByZWFkIHRoZSBuZXdzIGFuZCBkb2NzIHRvIGtub3cgaG93IGhhbmRsZSB3aGVuIGl0J3MgcmVtb3ZlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IG9uUGxheWVyRXhwcmVzc2lvbk9ic2VydmFibGUgPSBuZXcgT2JzZXJ2YWJsZTxJRXZlbnRzWydwbGF5ZXJFeHByZXNzaW9uJ10+KFxuICBjcmVhdGVTdWJzY3JpYmVyKCdwbGF5ZXJFeHByZXNzaW9uJylcbilcblxuLyoqXG4gKiBAcHVibGljXG4gKiBAZGVwcmVjYXRlZCBUaGlzIGZ1bmN0aW9uIGlzIGFuIGluaGVyaXRhbmNlIG9mIEVDUzYsIGl0J3MgaGVyZSB0ZW1wb3JhcnkgZm9yIHRoZSBmZWF0dXJlIHBhcml0eSwgcGxlYXNlIHJlYWQgdGhlIG5ld3MgYW5kIGRvY3MgdG8ga25vdyBob3cgaGFuZGxlIHdoZW4gaXQncyByZW1vdmVkLlxuICovXG5leHBvcnQgY29uc3Qgb25WaWRlb0V2ZW50ID0gbmV3IE9ic2VydmFibGU8SUV2ZW50c1sndmlkZW9FdmVudCddPihjcmVhdGVTdWJzY3JpYmVyKCd2aWRlb0V2ZW50JykpXG5cbi8qKlxuICogQHB1YmxpY1xuICogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiBpcyBhbiBpbmhlcml0YW5jZSBvZiBFQ1M2LCBpdCdzIGhlcmUgdGVtcG9yYXJ5IGZvciB0aGUgZmVhdHVyZSBwYXJpdHksIHBsZWFzZSByZWFkIHRoZSBuZXdzIGFuZCBkb2NzIHRvIGtub3cgaG93IGhhbmRsZSB3aGVuIGl0J3MgcmVtb3ZlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IG9uUHJvZmlsZUNoYW5nZWQgPSBuZXcgT2JzZXJ2YWJsZTxJRXZlbnRzWydwcm9maWxlQ2hhbmdlZCddPihjcmVhdGVTdWJzY3JpYmVyKCdwcm9maWxlQ2hhbmdlZCcpKVxuXG4vKipcbiAqIEBwdWJsaWNcbiAqIEBkZXByZWNhdGVkIFRoaXMgZnVuY3Rpb24gaXMgYW4gaW5oZXJpdGFuY2Ugb2YgRUNTNiwgaXQncyBoZXJlIHRlbXBvcmFyeSBmb3IgdGhlIGZlYXR1cmUgcGFyaXR5LCBwbGVhc2UgcmVhZCB0aGUgbmV3cyBhbmQgZG9jcyB0byBrbm93IGhvdyBoYW5kbGUgd2hlbiBpdCdzIHJlbW92ZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBvblBsYXllckNvbm5lY3RlZE9ic2VydmFibGUgPSBuZXcgT2JzZXJ2YWJsZTxJRXZlbnRzWydwbGF5ZXJDb25uZWN0ZWQnXT4oXG4gIGNyZWF0ZVN1YnNjcmliZXIoJ3BsYXllckNvbm5lY3RlZCcpXG4pXG5cbi8qKlxuICogQHB1YmxpY1xuICogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiBpcyBhbiBpbmhlcml0YW5jZSBvZiBFQ1M2LCBpdCdzIGhlcmUgdGVtcG9yYXJ5IGZvciB0aGUgZmVhdHVyZSBwYXJpdHksIHBsZWFzZSByZWFkIHRoZSBuZXdzIGFuZCBkb2NzIHRvIGtub3cgaG93IGhhbmRsZSB3aGVuIGl0J3MgcmVtb3ZlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IG9uUGxheWVyRGlzY29ubmVjdGVkT2JzZXJ2YWJsZSA9IG5ldyBPYnNlcnZhYmxlPElFdmVudHNbJ3BsYXllckRpc2Nvbm5lY3RlZCddPihcbiAgY3JlYXRlU3Vic2NyaWJlcigncGxheWVyRGlzY29ubmVjdGVkJylcbilcblxuLyoqXG4gKiBAcHVibGljXG4gKiBAZGVwcmVjYXRlZCBUaGlzIGZ1bmN0aW9uIGlzIGFuIGluaGVyaXRhbmNlIG9mIEVDUzYsIGl0J3MgaGVyZSB0ZW1wb3JhcnkgZm9yIHRoZSBmZWF0dXJlIHBhcml0eSwgcGxlYXNlIHJlYWQgdGhlIG5ld3MgYW5kIGRvY3MgdG8ga25vdyBob3cgaGFuZGxlIHdoZW4gaXQncyByZW1vdmVkLlxuICovXG5leHBvcnQgY29uc3Qgb25SZWFsbUNoYW5nZWRPYnNlcnZhYmxlID0gbmV3IE9ic2VydmFibGU8SUV2ZW50c1snb25SZWFsbUNoYW5nZWQnXT4oY3JlYXRlU3Vic2NyaWJlcignb25SZWFsbUNoYW5nZWQnKSlcblxuLyoqXG4gKiBAcHVibGljXG4gKiBAZGVwcmVjYXRlZCBUaGlzIGZ1bmN0aW9uIGlzIGFuIGluaGVyaXRhbmNlIG9mIEVDUzYsIGl0J3MgaGVyZSB0ZW1wb3JhcnkgZm9yIHRoZSBmZWF0dXJlIHBhcml0eSwgcGxlYXNlIHJlYWQgdGhlIG5ld3MgYW5kIGRvY3MgdG8ga25vdyBob3cgaGFuZGxlIHdoZW4gaXQncyByZW1vdmVkLlxuICovXG5leHBvcnQgY29uc3Qgb25QbGF5ZXJDbGlja2VkT2JzZXJ2YWJsZSA9IG5ldyBPYnNlcnZhYmxlPElFdmVudHNbJ3BsYXllckNsaWNrZWQnXT4oY3JlYXRlU3Vic2NyaWJlcigncGxheWVyQ2xpY2tlZCcpKVxuXG4vKipcbiAqIEBpbnRlcm5hbFxuICogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiBpcyBhbiBpbmhlcml0YW5jZSBvZiBFQ1M2LCBpdCdzIGhlcmUgdGVtcG9yYXJ5IGZvciB0aGUgZmVhdHVyZSBwYXJpdHksIHBsZWFzZSByZWFkIHRoZSBuZXdzIGFuZCBkb2NzIHRvIGtub3cgaG93IGhhbmRsZSB3aGVuIGl0J3MgcmVtb3ZlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IG9uQ29tbXNNZXNzYWdlID0gbmV3IE9ic2VydmFibGU8SUV2ZW50c1snY29tbXMnXT4oY3JlYXRlU3Vic2NyaWJlcignY29tbXMnKSlcblxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqIEBkZXByZWNhdGVkIHRoaXMgaXMgYW4gT0xEIEFQSS5cbiAqIFRoaXMgZnVuY3Rpb24gdXNlcyB0aGUgU0RLNiBzZW5kQmF0Y2ggdG8gcG9sbCBldmVudHMgZnJvbSB0aGUgcmVuZGVyZXJcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBvbGxFdmVudHMoc2VuZEJhdGNoOiAoYm9keTogTWFueUVudGl0eUFjdGlvbikgPT4gUHJvbWlzZTxTZW5kQmF0Y2hSZXNwb25zZT4pIHtcbiAgY29uc3QgeyBldmVudHMgfSA9IGF3YWl0IHNlbmRCYXRjaCh7IGFjdGlvbnM6IFtdIH0pXG4gIGZvciAoY29uc3QgZSBvZiBldmVudHMpIHtcbiAgICBpZiAoZS5nZW5lcmljKSB7XG4gICAgICBjb25zdCBkYXRhID0gSlNPTi5wYXJzZShlLmdlbmVyaWMuZXZlbnREYXRhKVxuICAgICAgc3dpdGNoIChlLmdlbmVyaWMuZXZlbnRJZCkge1xuICAgICAgICBjYXNlICdjb21tcyc6IHtcbiAgICAgICAgICBvbkNvbW1zTWVzc2FnZS5ub3RpZnlPYnNlcnZlcnMoZGF0YSBhcyBJRXZlbnRzWydjb21tcyddKVxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuY29uc3QgU0RLN0NvbXBvbmVudHNPYnNlcnZhYmxlID0gcHJvY2Vzc09ic2VydmFibGVzKClcbmZ1bmN0aW9uIHByb2Nlc3NPYnNlcnZhYmxlcygpIHtcbiAgY29uc3Qgc3Vic2NyaXB0aW9ucyA9IG5ldyBTZXQ8a2V5b2YgSUV2ZW50cz4oKVxuXG4gIGZ1bmN0aW9uIHN1YnNjcmliZShldmVudE5hbWU6IGtleW9mIElFdmVudHMpIHtcbiAgICBpZiAoc3Vic2NyaXB0aW9ucy5oYXMoZXZlbnROYW1lKSkgcmV0dXJuXG4gICAgc3dpdGNoIChldmVudE5hbWUpIHtcbiAgICAgIGNhc2UgJ3BsYXllckNsaWNrZWQnOiB7XG4gICAgICAgIHN1YnNjcmliZVBsYXllckNsaWNrKClcbiAgICAgICAgYnJlYWtcbiAgICAgIH1cbiAgICAgIGNhc2UgJ29uRW50ZXJTY2VuZSc6XG4gICAgICBjYXNlICdwbGF5ZXJDb25uZWN0ZWQnOiB7XG4gICAgICAgIHN1YnNjcmliZUVudGVyU2NlbmUoKVxuICAgICAgICBicmVha1xuICAgICAgfVxuICAgICAgY2FzZSAnb25MZWF2ZVNjZW5lJzpcbiAgICAgIGNhc2UgJ3BsYXllckRpc2Nvbm5lY3RlZCc6IHtcbiAgICAgICAgc3Vic2NyaWJlTGVhdmVTY2VuZSgpXG4gICAgICAgIGJyZWFrXG4gICAgICB9XG4gICAgICBjYXNlICdvblJlYWxtQ2hhbmdlZCc6IHtcbiAgICAgICAgc3Vic2NyaWJlUmVhbG1DaGFuZ2UoKVxuICAgICAgICBicmVha1xuICAgICAgfVxuICAgICAgY2FzZSAncGxheWVyRXhwcmVzc2lvbic6IHtcbiAgICAgICAgc3Vic2NyaWJlUGxheWVyRXhwcmVzc2lvbigpXG4gICAgICAgIGJyZWFrXG4gICAgICB9XG4gICAgICBjYXNlICdwcm9maWxlQ2hhbmdlZCc6IHtcbiAgICAgICAgc3Vic2NyaWJlUHJvZmlsZUNoYW5nZSgpXG4gICAgICAgIGJyZWFrXG4gICAgICB9XG4gICAgfVxuICAgIHN1YnNjcmlwdGlvbnMuYWRkKGV2ZW50TmFtZSlcbiAgfVxuICAvKipcbiAgICogUExBWUVSIEVOVEVSL0NPTk5FQ1RFRCBvYnNlcnZhYmxlXG4gICAqL1xuICBmdW5jdGlvbiBzdWJzY3JpYmVFbnRlclNjZW5lKCkge1xuICAgIHBsYXllcnMub25FbnRlclNjZW5lKChwbGF5ZXIpID0+IHtcbiAgICAgIGlmIChzdWJzY3JpcHRpb25zLmhhcygnb25FbnRlclNjZW5lJykpIHtcbiAgICAgICAgb25FbnRlclNjZW5lT2JzZXJ2YWJsZS5ub3RpZnlPYnNlcnZlcnMoeyB1c2VySWQ6IHBsYXllci51c2VySWQgfSlcbiAgICAgIH1cblxuICAgICAgaWYgKHN1YnNjcmlwdGlvbnMuaGFzKCdwbGF5ZXJDb25uZWN0ZWQnKSkge1xuICAgICAgICBvblBsYXllckNvbm5lY3RlZE9ic2VydmFibGUubm90aWZ5T2JzZXJ2ZXJzKHsgdXNlcklkOiBwbGF5ZXIudXNlcklkIH0pXG4gICAgICB9XG4gICAgfSlcbiAgfVxuICAvKipcbiAgICogUExBWUVSIExFQVZFL0RJU0NPTk5FQ1RFRCBvYnNlcnZhYmxlXG4gICAqL1xuICBmdW5jdGlvbiBzdWJzY3JpYmVMZWF2ZVNjZW5lKCkge1xuICAgIHBsYXllcnMub25MZWF2ZVNjZW5lKCh1c2VySWQpID0+IHtcbiAgICAgIGlmIChzdWJzY3JpcHRpb25zLmhhcygnb25MZWF2ZVNjZW5lJykpIHtcbiAgICAgICAgb25MZWF2ZVNjZW5lT2JzZXJ2YWJsZS5ub3RpZnlPYnNlcnZlcnMoeyB1c2VySWQgfSlcbiAgICAgIH1cblxuICAgICAgaWYgKHN1YnNjcmlwdGlvbnMuaGFzKCdwbGF5ZXJEaXNjb25uZWN0ZWQnKSkge1xuICAgICAgICBvblBsYXllckRpc2Nvbm5lY3RlZE9ic2VydmFibGUubm90aWZ5T2JzZXJ2ZXJzKHsgdXNlcklkIH0pXG4gICAgICB9XG4gICAgfSlcbiAgfVxuICAvKipcbiAgICogUkVBTE0gQ0hBTkdFIG9ic2VydmFibGVcbiAgICovXG4gIGZ1bmN0aW9uIHN1YnNjcmliZVJlYWxtQ2hhbmdlKCkge1xuICAgIFJlYWxtSW5mby5vbkNoYW5nZShlbmdpbmUuUm9vdEVudGl0eSwgKHZhbHVlKSA9PiB7XG4gICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgb25SZWFsbUNoYW5nZWRPYnNlcnZhYmxlLm5vdGlmeU9ic2VydmVycyh7XG4gICAgICAgICAgZG9tYWluOiB2YWx1ZS5iYXNlVXJsLFxuICAgICAgICAgIGRpc3BsYXlOYW1lOiB2YWx1ZS5yZWFsbU5hbWUsXG4gICAgICAgICAgcm9vbTogdmFsdWUucm9vbSA/PyAnJyxcbiAgICAgICAgICBzZXJ2ZXJOYW1lOiB2YWx1ZS5yZWFsbU5hbWVcbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9KVxuICB9XG4gIC8qKlxuICAgKiBQTEFZRVIvQVZBVEFSIENMSUNLRUQgb2JzZXJ2YWJsZVxuICAgKi9cbiAgZnVuY3Rpb24gc3Vic2NyaWJlUGxheWVyQ2xpY2soKSB7XG4gICAgY29uc3QgcGxheWVyRW50aXRpZXMgPSBuZXcgU2V0PEVudGl0eT4oKVxuICAgIGVuZ2luZS5hZGRTeXN0ZW0oKCkgPT4ge1xuICAgICAgZm9yIChjb25zdCBbZW50aXR5XSBvZiBlbmdpbmUuZ2V0RW50aXRpZXNXaXRoKFBsYXllcklkZW50aXR5RGF0YSkpIHtcbiAgICAgICAgaWYgKHBsYXllckVudGl0aWVzLmhhcyhlbnRpdHkpKSBjb250aW51ZVxuICAgICAgICBwbGF5ZXJFbnRpdGllcy5hZGQoZW50aXR5KVxuXG4gICAgICAgIFBvaW50ZXJFdmVudHNSZXN1bHQub25DaGFuZ2UoZW50aXR5LCAoZGF0YSkgPT4ge1xuICAgICAgICAgIGlmIChkYXRhPy5oaXQpIHtcbiAgICAgICAgICAgIG9uUGxheWVyQ2xpY2tlZE9ic2VydmFibGUubm90aWZ5T2JzZXJ2ZXJzKHtcbiAgICAgICAgICAgICAgdXNlcklkOiBQbGF5ZXJJZGVudGl0eURhdGEuZ2V0T3JOdWxsKGVudGl0eSk/LmFkZHJlc3MgPz8gJycsXG4gICAgICAgICAgICAgIHJheToge1xuICAgICAgICAgICAgICAgIGRpcmVjdGlvbjogZGF0YS5oaXQuZGlyZWN0aW9uISxcbiAgICAgICAgICAgICAgICBkaXN0YW5jZTogZGF0YS5oaXQubGVuZ3RoLFxuICAgICAgICAgICAgICAgIG9yaWdpbjogZGF0YS5oaXQuZ2xvYmFsT3JpZ2luIVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgLyoqXG4gICAqIFBsYXllciBleHByZXNzaW9uIG9ic2VydmFibGVcbiAgICovXG4gIGZ1bmN0aW9uIHN1YnNjcmliZVBsYXllckV4cHJlc3Npb24oKSB7XG4gICAgQXZhdGFyRW1vdGVDb21tYW5kLm9uQ2hhbmdlKGVuZ2luZS5QbGF5ZXJFbnRpdHksICh2YWx1ZSkgPT4ge1xuICAgICAgb25QbGF5ZXJFeHByZXNzaW9uT2JzZXJ2YWJsZS5ub3RpZnlPYnNlcnZlcnMoeyBleHByZXNzaW9uSWQ6IHZhbHVlPy5lbW90ZVVybiA/PyAnJyB9KVxuICAgIH0pXG4gIH1cblxuICAvKipcbiAgICogUFJPRklMRSBDSEFOR0Ugb2JzZXJ2YWJsZVxuICAgKi9cbiAgZnVuY3Rpb24gc3Vic2NyaWJlUHJvZmlsZUNoYW5nZSgpIHtcbiAgICBBdmF0YXJCYXNlLm9uQ2hhbmdlKGVuZ2luZS5QbGF5ZXJFbnRpdHksICgpID0+IHtcbiAgICAgIGlmICghcHJvZmlsZUFkZHJlc3MpIHJldHVyblxuICAgICAgb25Qcm9maWxlQ2hhbmdlZC5ub3RpZnlPYnNlcnZlcnMoeyBldGhBZGRyZXNzOiBwcm9maWxlQWRkcmVzcywgdmVyc2lvbjogMCB9KVxuICAgIH0pXG5cbiAgICBBdmF0YXJFcXVpcHBlZERhdGEub25DaGFuZ2UoZW5naW5lLlBsYXllckVudGl0eSwgKCkgPT4ge1xuICAgICAgaWYgKCFwcm9maWxlQWRkcmVzcykgcmV0dXJuXG4gICAgICBvblByb2ZpbGVDaGFuZ2VkLm5vdGlmeU9ic2VydmVycyh7IGV0aEFkZHJlc3M6IHByb2ZpbGVBZGRyZXNzLCB2ZXJzaW9uOiAwIH0pXG4gICAgfSlcbiAgfVxuXG4gIC8vIEZsYWcgdG8gY2FsbCBvbmNlIHRoZSBzY2VuZSBpcyBpbml0YWxpemVkLlxuICBsZXQgc2NlbmVSZWFkeSA9IGZhbHNlXG4gIGxldCBwcm9maWxlQWRkcmVzczogc3RyaW5nIHwgdW5kZWZpbmVkXG5cbiAgZnVuY3Rpb24gb2JzZXJ2YWJsZVN5c3RlbSgpIHtcbiAgICBpZiAoc2NlbmVSZWFkeSAmJiBwcm9maWxlQWRkcmVzcykge1xuICAgICAgcmV0dXJuIGVuZ2luZS5yZW1vdmVTeXN0ZW0ob2JzZXJ2YWJsZVN5c3RlbSlcbiAgICB9XG4gICAgaWYgKCFzY2VuZVJlYWR5KSB7XG4gICAgICBzY2VuZVJlYWR5ID0gdHJ1ZVxuICAgICAgb25TY2VuZVJlYWR5T2JzZXJ2YWJsZS5ub3RpZnlPYnNlcnZlcnMoe30pXG4gICAgfVxuICAgIGlmIChwcm9maWxlQWRkcmVzcykgcmV0dXJuXG4gICAgcHJvZmlsZUFkZHJlc3MgPSBQbGF5ZXJJZGVudGl0eURhdGEuZ2V0T3JOdWxsKGVuZ2luZS5QbGF5ZXJFbnRpdHkpPy5hZGRyZXNzXG4gIH1cblxuICBlbmdpbmUuYWRkU3lzdGVtKG9ic2VydmFibGVTeXN0ZW0pXG5cbiAgcmV0dXJuIHsgc3Vic2NyaWJlIH1cbn1cbiJdfQ==