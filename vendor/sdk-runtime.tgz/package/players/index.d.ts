import { Entity, IEngine, TransformType } from '@dcl/ecs';
import { PBAvatarBase, PBAvatarEquippedData } from '@dcl/ecs/dist/components';
type GetPlayerDataReq = {
    userId: string;
};
type GetPlayerDataRes = {
    entity: Entity;
    name: string;
    isGuest: boolean;
    userId: string;
    avatar?: PBAvatarBase;
    wearables: PBAvatarEquippedData['wearableUrns'];
    emotes: PBAvatarEquippedData['emoteUrns'];
    position: TransformType['position'] | undefined;
};
export declare function definePlayerHelper(engine: IEngine): {
    onEnterScene(cb: (player: GetPlayerDataRes) => void): void;
    onLeaveScene(cb: (userId: string) => void): void;
    /**
     * Returns the info of the player if it's in the scene.
     */
    getPlayer(user?: GetPlayerDataReq): GetPlayerDataRes | null;
};
declare const players: {
    onEnterScene(cb: (player: GetPlayerDataRes) => void): void;
    onLeaveScene(cb: (userId: string) => void): void;
    /**
     * Returns the info of the player if it's in the scene.
     */
    getPlayer(user?: GetPlayerDataReq): GetPlayerDataRes | null;
};
declare const getPlayer: (user?: GetPlayerDataReq) => GetPlayerDataRes | null, onEnterScene: (cb: (player: GetPlayerDataRes) => void) => void, onLeaveScene: (cb: (userId: string) => void) => void;
export { getPlayer, onEnterScene, onLeaveScene };
export default players;
