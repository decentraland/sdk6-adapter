import { IEngine, ComponentDefinition } from '@dcl/ecs';
export declare const NOT_SYNC_COMPONENTS: ComponentDefinition<unknown>[];
export declare const NOT_SYNC_COMPONENTS_IDS: number[];
export declare const NOT_SYNC_COMPONENTS_NAMES: string[];
export declare function shouldSyncComponent(component: ComponentDefinition<unknown>): boolean;
export declare function getDesyncedComponents(engine: IEngine): ComponentDefinition<unknown>[];
export declare function engineToCrdt(engine: IEngine): Uint8Array[];
