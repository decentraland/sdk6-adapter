export declare enum CommsMessage {
    CRDT = 1,
    REQ_CRDT_STATE = 2,
    RES_CRDT_STATE = 3
}
export declare function BinaryMessageBus<T extends CommsMessage>(send: (message: Uint8Array, toPeerAddress?: string[]) => void): {
    on: <K extends T>(message: K, callback: (value: Uint8Array, sender: string) => void) => void;
    emit: <K_1 extends T>(message: K_1, value: Uint8Array, toPeerAddress?: string[]) => void;
    __processMessages: (messages: Uint8Array[]) => void;
};
export declare function craftCommsMessage<T extends CommsMessage>(messageType: T, payload: Uint8Array): Uint8Array;
export declare function decodeCommsMessage<T extends CommsMessage>(data: Uint8Array): {
    sender: string;
    messageType: T;
    data: Uint8Array;
} | undefined;
export declare function decodeString(data: Uint8Array): string;
export declare function encodeString(s: string): Uint8Array;
