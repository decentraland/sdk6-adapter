/// <reference types="@dcl/js-runtime" />
import { IEngine } from '@dcl/ecs';
import { type SendBinaryRequest, type SendBinaryResponse } from '~system/CommunicationsController';
import { GetUserDataRequest, GetUserDataResponse } from '~system/UserIdentity';
export type IProfile = {
    networkId: number;
    userId: string;
};
export declare function addSyncTransport(engine: IEngine, sendBinary: (msg: SendBinaryRequest) => Promise<SendBinaryResponse>, getUserData: (value: GetUserDataRequest) => Promise<GetUserDataResponse>): {
    myProfile: IProfile;
    isStateSyncronized: () => boolean;
    syncEntity: (entityId: import("@dcl/ecs").Entity, componentIds: number[], entityEnumId?: number | undefined) => void;
    getChildren: (parent: import("@dcl/ecs").Entity) => Iterable<import("@dcl/ecs").Entity>;
    getParent: (child: import("@dcl/ecs").Entity) => import("@dcl/ecs").Entity | undefined;
    parentEntity: (entity: import("@dcl/ecs").Entity, parent: import("@dcl/ecs").Entity) => void;
    removeParent: (entity: import("@dcl/ecs").Entity) => void;
    getFirstChild: (entity: import("@dcl/ecs").Entity) => import("@dcl/ecs").Entity;
};
