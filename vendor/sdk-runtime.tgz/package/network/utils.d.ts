/// <reference types="@dcl/js-runtime" />
import type { GetUserDataRequest, GetUserDataResponse } from '~system/UserIdentity';
import { IProfile } from './message-bus-sync';
export declare function fetchProfile(myProfile: IProfile, getUserData: (value: GetUserDataRequest) => Promise<GetUserDataResponse>): void;
