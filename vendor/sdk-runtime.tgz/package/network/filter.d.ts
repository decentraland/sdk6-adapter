import { TransportMessage, IEngine } from '@dcl/ecs';
export declare function syncFilter(engine: IEngine): (message: Omit<TransportMessage, 'messageBuffer'>) => boolean;
