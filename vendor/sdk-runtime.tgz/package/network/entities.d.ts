import { Entity, IEngine } from '@dcl/ecs';
import { IProfile } from './message-bus-sync';
export type SyncEntity = (entityId: Entity, componentIds: number[], entityEnumId?: number) => void;
export declare function entityUtils(engine: IEngine, profile: IProfile): {
    syncEntity: (entityId: Entity, componentIds: number[], entityEnumId?: number) => void;
    getChildren: (parent: Entity) => Iterable<Entity>;
    getParent: (child: Entity) => Entity | undefined;
    parentEntity: (entity: Entity, parent: Entity) => void;
    removeParent: (entity: Entity) => void;
    getFirstChild: (entity: Entity) => Entity;
};
