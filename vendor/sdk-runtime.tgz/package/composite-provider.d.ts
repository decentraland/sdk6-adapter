import { Composite } from '@dcl/ecs';
export declare const compositeProvider: Composite.Provider;
