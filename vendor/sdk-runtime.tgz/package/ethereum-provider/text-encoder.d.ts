export { polyfillTextEncoder } from '../text-codec';
