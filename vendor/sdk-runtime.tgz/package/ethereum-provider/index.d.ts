/**
 * This module is exposed by the sdk via `@dcl/sdk/etherum-provider`
 *

* @example
 * ```tsx
 * import { createEthereumProvider } from '@dcl/sdk/ethereum-provider'
 * import { ethers } from 'ethers'

 * const provider = new ethers.providers.Web3Provider(createEthereumProvider() as any)
 * ```
 *
 * @module Etherum Provider
 *
 */
/**
 * Etherum Provider
 * @public
 */
export declare function createEthereumProvider(): {
    send(message: import("../internal/provider").RPCSendableMessage, callback?: ((error: Error | null, result?: any) => void) | undefined): void;
    sendAsync(message: import("../internal/provider").RPCSendableMessage, callback: (error: Error | null, result?: any) => void): void;
};
export { RPCSendableMessage } from '../internal/provider';
